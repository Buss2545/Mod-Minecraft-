package com.example.samurai;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class EntityElder extends EntityNpc {

    private static final String[] LINES = {
        "{call} ตีดาบคาตานะสิ ใช้เหล็กสองแท่งวางเฉียงกับไม้หนึ่งแท่งที่ด้ามจับ ดาบดีเริ่มจากมือของเจ้าเอง",
        "ได้ยินเสียงคำรามไหม พวกโอนิออกมาแล้ว ฟันพวกมันให้ครบสิบตัว แล้วราชาของพวกมันจะโผล่มา ระวังการทุบพื้นของมันให้ดี",
        "ประตูแห่งโยมิสร้างจากออบซิเดียน เรียงเป็นกรอบสูงห้าเต็มกว้างสี่ แล้วจุดไฟด้วยหินเหล็กไฟ ระวังตัวให้ดี ลาวาเยอะ",
        "งูแปดหัวไม่ใช่ศัตรูธรรมดา หาเนเธอร์วอร์ตแปดต้นจากป้อมปราการในโยมิ วางล้อมทองหนึ่งแท่งเป็นเครื่องบูชาสาเก แล้วใช้มันที่พื้นโยมิ มันจะโผล่มาเอง ตำนานว่าดาบเทพซ่อนอยู่ในหางของมัน",
        "เหล่าเทพบอกว่าสุดขอบฟ้ามีประตูซ่อนอยู่ใต้ดิน จงใช้ไข่มุกเอนเดอร์ตามหาป้อมปราการ",
        "มังกรผู้ดูดกลืนแสงอาทิตย์อยู่ตรงหน้าเจ้าแล้ว ทำลายคริสตัลบนเสาก่อน แล้วค่อยฟันมัน",
    };
    private static final String DONE = "อาทิตย์ขึ้นอีกครั้งแล้ว ข้าภูมิใจในตัวเจ้ามาก ซามูไรแห่งตำนาน หากอยากออกเดินทางอีกครั้ง จงใช้ม้วนคัมภีร์ขณะย่อตัว (Shift + คลิกขวา)";

    public EntityElder(World world) {
        super(world);
    }

    @Override
    protected String getSpeakerName() { return "ปรมาจารย์เฒ่า"; }

    @Override
    protected String getLine(EntityPlayer p, StoryProperties s) {
        if (s.isFinished()) return DONE;
        String call = ProfileData.getGender(p) == ProfileData.FEMALE ? "แม่หนู" : "เจ้าหนู";
        return LINES[s.chapter].replace("{call}", call);
    }
}
