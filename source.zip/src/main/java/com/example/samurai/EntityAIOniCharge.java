package com.example.samurai;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

/** โอนิพุ่งชน: ยกแขนเตือนสั้นๆ (ปัดป้องหรือหลบได้) แล้วพุ่งเข้าใส่เป้าหมาย */
public class EntityAIOniCharge extends EntityAIBase {
    private final EntityOni oni;
    private EntityLivingBase target;
    private int cooldown = 60, windup, dash;

    public EntityAIOniCharge(EntityOni oni) {
        this.oni = oni;
        setMutexBits(3); // ยึดการเดินและการมอง ไม่ให้ AI โจมตีปกติมาแย่ง
    }

    @Override
    public boolean shouldExecute() {
        if (cooldown > 0) { cooldown--; return false; }
        EntityLivingBase t = oni.getAttackTarget();
        if (t == null || !t.isEntityAlive() || !oni.onGround) return false;
        double d = oni.getDistanceSqToEntity(t);
        if (d < 16.0D || d > 100.0D || !oni.getEntitySenses().canSee(t)) return false;
        target = t;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        return target != null && target.isEntityAlive() && (windup > 0 || dash > 0);
    }

    @Override
    public void startExecuting() {
        windup = 16;
        dash = 0;
        oni.getNavigator().clearPathEntity();
        oni.setAnimState(EntityOni.ST_WINDUP);
        oni.worldObj.playSoundAtEntity(oni, "mob.enderdragon.growl", 1.0F, 1.5F);
    }

    @Override
    public void updateTask() {
        oni.getLookHelper().setLookPositionWithEntity(target, 30.0F, 30.0F);
        if (windup > 0) {
            oni.getNavigator().clearPathEntity();
            if (--windup == 0) {
                double dx = target.posX - oni.posX, dz = target.posZ - oni.posZ;
                double len = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
                oni.motionX = dx / len * 1.5D;
                oni.motionZ = dz / len * 1.5D;
                oni.motionY = 0.3D;
                oni.velocityChanged = true;
                dash = 10;
                oni.setAnimState(EntityOni.ST_STRIKE);
            }
        } else if (dash > 0) {
            dash--;
            if (oni.getDistanceSqToEntity(target) < 3.0D) {
                oni.attackEntityAsMob(target);
                dash = 0;
            }
        }
    }

    @Override
    public void resetTask() {
        target = null;
        windup = 0;
        dash = 0;
        cooldown = 100 + oni.getRNG().nextInt(80);
        oni.setAnimState(EntityOni.ST_AGGRO);
    }
}
