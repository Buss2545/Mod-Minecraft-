package com.example.samurai;

import net.minecraft.entity.ai.EntityAIBase;

/** กิจวัตรประจำวันของชาวบ้าน: ทำงาน -> พักที่ลาน -> กลับบ้านนอน (ฝนตกก็หลบเข้าบ้าน) */
public class EntityAIRoutine extends EntityAIBase {
    private final EntityVillagerNpc npc;
    private final double speed;
    private int lastPhase = -1, repath, stuck;
    private double tx, ty, tz;

    public EntityAIRoutine(EntityVillagerNpc npc, double speed) {
        this.npc = npc;
        this.speed = speed;
        setMutexBits(3); // ยึดทั้งการเดินและการมอง ไม่ให้ AI เดินเล่นสุ่มมาแย่ง
    }

    @Override
    public boolean shouldExecute() { return npc.hasRoutine; }

    @Override
    public void updateTask() {
        int phase = npc.getPhase();
        if (phase != lastPhase) {
            lastPhase = phase;
            stuck = 0;
            repath = 0;
            pickTarget(phase);
        }

        if (npc.getDistanceSq(tx, ty, tz) > 2.0D) {
            if (--repath <= 0) {
                repath = 40;
                if (++stuck > 12) { // เดินไม่ถึงนานเกิน ~20 วิ: วาร์ปกันติด
                    npc.setPositionAndUpdate(tx, ty, tz);
                    stuck = 0;
                } else {
                    npc.getNavigator().tryMoveToXYZ(tx, ty, tz, speed);
                }
            }
        } else {
            stuck = 0;
            npc.getNavigator().clearPathEntity();
            if (phase == EntityVillagerNpc.WORK) {
                if (npc.ticksExisted % 40 == 0) npc.swingItem(); // ท่าทางทำงาน
            } else if (phase == EntityVillagerNpc.PLAZA && npc.getRNG().nextInt(120) == 0) {
                pickTarget(phase); // เดินเตร่รอบลาน
            }
        }
    }

    private void pickTarget(int phase) {
        if (phase == EntityVillagerNpc.WORK) {
            tx = npc.workX; ty = npc.workY; tz = npc.workZ;
        } else if (phase == EntityVillagerNpc.PLAZA) {
            tx = npc.plazaX + (npc.getRNG().nextDouble() - 0.5D) * 3.0D;
            ty = npc.workY;
            tz = npc.plazaZ + (npc.getRNG().nextDouble() - 0.5D) * 3.0D;
        } else {
            tx = npc.homeX; ty = npc.homeY; tz = npc.homeZ;
        }
    }
}
