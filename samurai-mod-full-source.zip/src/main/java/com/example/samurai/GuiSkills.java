package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

@SideOnly(Side.CLIENT)
public class GuiSkills extends GuiScreen {
    private static final int W = 220, H = 216, ROW = 35;
    private int left, top;

    @Override
    public void initGui() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        buttonList.clear();
        for (int i = 0; i < SkillData.COUNT; i++)
            buttonList.add(new GuiButton(i, left + W - 62, top + 36 + i * ROW, 52, 20, ""));
        NetworkHandler.NET.sendToServer(new PacketUpgrade(-1)); // ขอข้อมูลล่าสุด
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        NetworkHandler.NET.sendToServer(new PacketUpgrade(b.id));
    }

    @Override
    public void drawScreen(int mx, int my, float partial) {
        drawDefaultBackground();
        drawRect(left - 2, top - 2, left + W + 2, top + H + 2, 0xFFB22222);
        drawRect(left, top, left + W, top + H, 0xF0202030);

        int cls = ProfileData.getClassId(mc.thePlayer);
        String who = cls >= 0
                ? ProfileData.CLASS_NAMES[cls] + " (" + ProfileData.GENDERS[ProfileData.getGender(mc.thePlayer)] + ")"
                : "ซามูไร";
        drawCenteredString(fontRendererObj, "ทักษะ - " + who, left + W / 2, top + 8, 0xFFD700);
        drawCenteredString(fontRendererObj, "XP เลเวล: " + mc.thePlayer.experienceLevel,
                left + W / 2, top + 20, 0x80FF20);

        for (int i = 0; i < SkillData.COUNT; i++) {
            int y = top + 34 + i * ROW;
            int lv = SkillData.getLevel(mc.thePlayer, i);

            fontRendererObj.drawString(SkillData.NAMES[i], left + 10, y, 0xFFFFFF);
            fontRendererObj.drawString(fontRendererObj.trimStringToWidth(SkillData.DESCS[i], W - 80),
                    left + 10, y + 11, 0xAAAAAA);
            for (int k = 0; k < SkillData.MAX; k++) {
                int bx = left + 10 + k * 14;
                drawRect(bx, y + 23, bx + 12, y + 29, k < lv ? 0xFFFFC107 : 0xFF444444);
            }

            GuiButton b = (GuiButton) buttonList.get(i);
            if (lv >= SkillData.MAX) {
                b.displayString = "MAX";
                b.enabled = false;
            } else {
                int c = SkillData.cost(lv);
                b.displayString = c + " Lv";
                b.enabled = mc.thePlayer.capabilities.isCreativeMode
                        || mc.thePlayer.experienceLevel >= c;
            }
        }
        super.drawScreen(mx, my, partial);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
