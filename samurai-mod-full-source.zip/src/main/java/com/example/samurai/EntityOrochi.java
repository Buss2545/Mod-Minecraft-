package com.example.samurai;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** ยามาตะโนะโอโรจิ: งูแปดหัว บอสตอนที่ 4 */
public class EntityOrochi extends EntityMob implements IBossDisplayData {
    private boolean enraged;
    private int volley, volleyDelay, breathCooldown = 100;

    public EntityOrochi(World world) {
        super(world);
        setSize(3.5F, 3.5F);
        isImmuneToFire = true;
        experienceValue = 500;
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
        tasks.addTask(2, new EntityAIWander(this, 0.6D));
        tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 32.0F));
        tasks.addTask(4, new EntityAILookIdle(this));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
    }

    @Override
    public boolean isAIEnabled() { return true; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(300.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.30D);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(10.0D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
        getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(1.0D);
    }

    @Override
    protected boolean canDespawn() { return false; }

    @Override protected String getLivingSound() { return "mob.wither.idle"; }
    @Override protected String getHurtSound()   { return "mob.wither.hurt"; }
    @Override protected String getDeathSound()  { return "mob.wither.death"; }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        dropItem(SamuraiMod.kusanagi, 1); // ดาบคุซานางิในหางงู ตามตำนาน
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (worldObj.isRemote) return;

        EntityLivingBase target = getAttackTarget();
        if (target == null) return;

        if (!enraged && getHealth() < getMaxHealth() * 0.5F) enrage();

        if (volley > 0) {
            if (--volleyDelay <= 0) {
                shoot(target);
                volley--;
                volleyDelay = 8;
            }
        } else if (--breathCooldown <= 0 && getDistanceSqToEntity(target) < 28.0D * 28.0D) {
            volley = enraged ? 5 : 3;
            breathCooldown = enraged ? 80 : 130;
        }
    }

    /** พ่นลูกไฟจากหัวสุ่มหัวหนึ่ง */
    private void shoot(EntityLivingBase target) {
        double hx = posX + (rand.nextDouble() - 0.5D) * 3.0D;
        double hy = posY + 3.0D + rand.nextDouble();
        double hz = posZ + (rand.nextDouble() - 0.5D) * 3.0D;
        double dx = target.posX - hx;
        double dy = target.boundingBox.minY + target.height / 2.0D - hy;
        double dz = target.posZ - hz;
        EntitySmallFireball fireball = new EntitySmallFireball(worldObj, this, dx, dy, dz);
        fireball.setPosition(hx, hy, hz);
        worldObj.spawnEntityInWorld(fireball);
        worldObj.playSoundAtEntity(this, "mob.ghast.fireball", 2.0F, 0.8F);
    }

    /** เลือดต่ำกว่าครึ่ง: เร็วขึ้น เรียกโอนิ 2 ตัว ยิงถี่ขึ้น */
    private void enrage() {
        enraged = true;
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.38D);
        for (int i = 0; i < 2; i++) {
            EntityOni oni = new EntityOni(worldObj);
            oni.setLocationAndAngles(posX + (i == 0 ? 4.0D : -4.0D), posY, posZ + 3.0D,
                    rand.nextFloat() * 360.0F, 0.0F);
            worldObj.spawnEntityInWorld(oni);
        }
        worldObj.playSoundAtEntity(this, "mob.wither.spawn", 2.0F, 0.7F);
        List players = worldObj.getEntitiesWithinAABB(EntityPlayer.class, boundingBox.expand(40.0D, 20.0D, 40.0D));
        for (Object o : players)
            ((EntityPlayer) o).addChatMessage(new ChatComponentText("ยามาตะโนะโอโรจิคลุ้มคลั่ง!"));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setBoolean("Enraged", enraged);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        enraged = tag.getBoolean("Enraged");
    }
}
