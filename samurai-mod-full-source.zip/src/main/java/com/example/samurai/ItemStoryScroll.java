package com.example.samurai;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

public class ItemStoryScroll extends Item {
    public ItemStoryScroll() {
        setUnlocalizedName("storyScroll");
        setTextureName(SamuraiMod.MODID + ":story_scroll");
        setCreativeTab(CreativeTabs.tabMisc);
        setMaxStackSize(1);
    }

    @Override
    public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
        if (world.isRemote) return stack;
        StoryProperties s = StoryProperties.get(player);
        if (s == null) return stack;

        // จบเรื่องแล้ว: คลิกขวา = ดูตอนจบ, Shift + คลิกขวา 2 ครั้ง = เริ่ม NG+
        if (s.isFinished()) {
            if (player.isSneaking()) {
                long now = world.getTotalWorldTime();
                if (now <= s.ngConfirmUntil) {
                    s.ngConfirmUntil = 0L;
                    s.startNewGamePlus(player);
                } else {
                    s.ngConfirmUntil = now + 200L; // ยืนยันภายใน 10 วินาที
                    player.addChatMessage(new ChatComponentText(
                            "ยืนยัน: กด Shift + คลิกขวาอีกครั้งภายใน 10 วินาที เพื่อเริ่ม NG+ (เนื้อเรื่องเริ่มใหม่ สกิลและคลาสยังอยู่ครบ)"));
                }
            } else {
                s.showChapter(player);
                player.addChatMessage(new ChatComponentText("Shift + คลิกขวา เพื่อเริ่มเล่นรอบใหม่ (NG+)"));
            }
            return stack;
        }

        s.showChapter(player);
        // กู้คืน: ฆ่าโอนิครบแล้วแต่โอนิราชาหายไป (ตายเพราะลาวา ฯลฯ) ให้เรียกใหม่
        if (s.chapter == 1 && s.zombieKills >= StoryManager.ZOMBIES_NEEDED && !kingAlive(world))
            EntityOniKing.summonNear(player);
        return stack;
    }

    private boolean kingAlive(World w) {
        for (Object o : w.loadedEntityList)
            if (o instanceof EntityOniKing && !((EntityOniKing) o).isDead) return true;
        return false;
    }
}
