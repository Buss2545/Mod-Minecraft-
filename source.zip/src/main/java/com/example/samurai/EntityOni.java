package com.example.samurai;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.world.World;

public class EntityOni extends EntityMob {
    /** สถานะแอนิเมชัน (ซิงก์ผ่าน DataWatcher ช่อง 20) */
    public static final int ST_IDLE = 0, ST_AGGRO = 1, ST_WINDUP = 2, ST_STRIKE = 3;

    /** ค่าแอนิเมชันฝั่งไคลเอนต์ 0..1 (ModelOni อ่านไปใช้) */
    public float aggro, raise, swing;
    private boolean frenzy;

    public EntityOni(World world) {
        super(world);
        setSize(0.8F, 2.4F);
        getNavigator().setBreakDoors(true);
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
        tasks.addTask(2, new EntityAIMoveTowardsRestriction(this, 1.0D));
        tasks.addTask(3, new EntityAIWander(this, 0.8D));
        tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(5, new EntityAILookIdle(this));
        if (!(this instanceof EntityOniKing)) tasks.addTask(0, new EntityAIOniCharge(this));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
        experienceValue = 15;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataWatcher.addObject(20, Byte.valueOf((byte) 0));
    }

    public int getAnimState() { return dataWatcher.getWatchableObjectByte(20); }

    public void setAnimState(int s) {
        if (!worldObj.isRemote) dataWatcher.updateObject(20, Byte.valueOf((byte) s));
    }

    private static float approach(float v, float target, float step) {
        return v < target ? Math.min(target, v + step) : Math.max(target, v - step);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        if (!worldObj.isRemote) {
            int s = getAnimState();
            if (s <= ST_AGGRO) setAnimState(getAttackTarget() != null ? ST_AGGRO : ST_IDLE);

            // เลือดต่ำกว่า 30%: คลั่ง วิ่งเร็วขึ้น (โอนิราชามีระบบคลั่งของตัวเอง)
            if (!frenzy && !(this instanceof EntityOniKing) && getHealth() < getMaxHealth() * 0.3F) {
                frenzy = true;
                getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.34D);
                worldObj.playSoundAtEntity(this, "mob.enderdragon.growl", 1.0F, 1.2F);
            }
        }

        int st = getAnimState();
        aggro = approach(aggro, st >= ST_AGGRO ? 1.0F : 0.0F, 0.1F);
        raise = approach(raise, st == ST_WINDUP ? 1.0F : 0.0F, st == ST_WINDUP ? 0.12F : 0.25F);
        swing = st == ST_STRIKE ? 1.0F : Math.max(0.0F, swing - 0.12F);
    }

    @Override
    public boolean isAIEnabled() { return true; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.26D);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(6.0D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(32.0D);
    }

    @Override protected String getLivingSound() { return "mob.zombie.say"; }
    @Override protected String getHurtSound()   { return "mob.zombie.hurt"; }
    @Override protected String getDeathSound()  { return "mob.zombie.death"; }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        if (rand.nextInt(3) == 0) dropItem(Items.iron_ingot, 1);
    }
}
