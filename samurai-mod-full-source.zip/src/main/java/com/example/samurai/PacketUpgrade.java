package com.example.samurai;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;

/** ไคลเอนต์ขออัพสกิล (ส่ง -1 = ขอซิงก์ข้อมูลเฉยๆ) */
public class PacketUpgrade implements IMessage {
    public int skill;

    public PacketUpgrade() {}
    public PacketUpgrade(int skill) { this.skill = skill; }

    @Override public void fromBytes(ByteBuf buf) { skill = buf.readInt(); }
    @Override public void toBytes(ByteBuf buf) { buf.writeInt(skill); }

    public static class Handler implements IMessageHandler<PacketUpgrade, IMessage> {
        @Override
        public IMessage onMessage(PacketUpgrade msg, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().playerEntity;
            final int skill = msg.skill;
            TaskQueue.add(new Runnable() {
                @Override public void run() {
                    if (skill >= 0) SkillData.tryUpgrade(p, skill);
                    SkillData.sync(p); // ส่งเลเวลล่าสุดกลับไปให้ UI
                }
            });
            return null;
        }
    }
}
