package com.example.samurai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.World;

public abstract class EntityNpc extends EntityCreature {

    public EntityNpc(World world) {
        super(world);
        setSize(0.6F, 1.8F);
        getNavigator().setAvoidsWater(true);
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(2, new EntityAIWander(this, 0.4D));
        tasks.addTask(3, new EntityAILookIdle(this));
    }

    @Override
    public boolean isAIEnabled() { return true; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D);
    }

    @Override
    protected boolean canDespawn() { return false; }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (source == DamageSource.outOfWorld) return super.attackEntityFrom(source, amount);
        return false;
    }

    @Override
    public boolean interact(EntityPlayer player) {
        if (!worldObj.isRemote) {
            StoryProperties story = StoryProperties.get(player);
            if (story != null) {
                ChatComponentText name = new ChatComponentText("[" + getSpeakerName() + "] ");
                name.getChatStyle().setColor(EnumChatFormatting.GOLD);
                ChatComponentText line = new ChatComponentText(getLine(player, story));
                line.getChatStyle().setColor(EnumChatFormatting.WHITE);
                name.appendSibling(line);
                player.addChatMessage(name);
            }
        }
        return true;
    }

    protected abstract String getSpeakerName();

    protected abstract String getLine(EntityPlayer player, StoryProperties story);
}
