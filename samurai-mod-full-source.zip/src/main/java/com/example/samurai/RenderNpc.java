package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

@SideOnly(Side.CLIENT)
public class RenderNpc extends RenderBiped {
    private final ResourceLocation texture;

    public RenderNpc(String textureName) {
        super(new ModelBiped(), 0.5F);
        texture = new ResourceLocation(SamuraiMod.MODID, "textures/entity/" + textureName + ".png");
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLiving entity) { return texture; }
}
