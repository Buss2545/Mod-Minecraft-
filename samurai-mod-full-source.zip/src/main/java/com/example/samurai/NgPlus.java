package com.example.samurai;

import java.util.UUID;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.WorldServer;

/** โหมดเล่นซ้ำ (NG+): บอสแข็งแกร่งขึ้นรอบละ +50% เลือด +25% ดาเมจ */
public class NgPlus {
    private static final UUID HP_ID = UUID.fromString("a3f1d9c2-7b64-4e1a-9d0b-5c2e8f4a6b17");
    private static final UUID DMG_ID = UUID.fromString("e8b27c40-1d95-4a3f-b6c8-90d4a7e15f23");

    public static void scale(EntityLivingBase boss, int ng) {
        if (ng <= 0) return;
        mul(boss.getEntityAttribute(SharedMonsterAttributes.maxHealth), HP_ID, "ng.hp", 0.5D * ng);
        mul(boss.getEntityAttribute(SharedMonsterAttributes.attackDamage), DMG_ID, "ng.dmg", 0.25D * ng);
        boss.setHealth(boss.getMaxHealth());
    }

    private static void mul(IAttributeInstance inst, UUID id, String name, double amount) {
        if (inst == null) return; // บอสบางตัว (เช่นมังกร) ไม่มี attribute ดาเมจ
        AttributeModifier old = inst.getModifier(id);
        if (old != null) inst.removeModifier(old);
        inst.applyModifier(new AttributeModifier(id, name, amount, 1)); // 1 = คูณเพิ่มจากค่ารวม
    }

    /** Minecraft 1.7.10 ไม่เสกมังกรใหม่เอง จึงเสกให้เมื่อผู้เล่นเข้า The End ในรอบ NG+ */
    public static void ensureDragon(EntityPlayer p, int ng) {
        WorldServer end = MinecraftServer.getServer().worldServerForDimension(1);
        for (Object o : end.loadedEntityList)
            if (o instanceof EntityDragon && !((EntityDragon) o).isDead) return;

        EntityDragon dragon = new EntityDragon(end);
        dragon.setLocationAndAngles(0.0D, 128.0D, 0.0D, end.rand.nextFloat() * 360.0F, 0.0F);
        scale(dragon, ng);
        end.spawnEntityInWorld(dragon);
        p.addChatMessage(new ChatComponentText("มังกรแห่งรัตติกาลกลับมาอีกครั้ง!"));
    }
}
