package com.example.samurai;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;

/** เซิร์ฟเวอร์ส่งเลเวลสกิล เพศ และคลาส ให้ไคลเอนต์ */
public class PacketSync implements IMessage {
    private final int[] levels = new int[SkillData.COUNT];
    private int gender, cls = -1;

    public PacketSync() {}
    public PacketSync(EntityPlayer p) {
        for (int i = 0; i < SkillData.COUNT; i++) levels[i] = SkillData.getLevel(p, i);
        gender = ProfileData.getGender(p);
        cls = ProfileData.getClassId(p);
    }

    @Override public void fromBytes(ByteBuf buf) {
        for (int i = 0; i < SkillData.COUNT; i++) levels[i] = buf.readInt();
        gender = buf.readInt();
        cls = buf.readInt();
    }
    @Override public void toBytes(ByteBuf buf) {
        for (int i = 0; i < SkillData.COUNT; i++) buf.writeInt(levels[i]);
        buf.writeInt(gender);
        buf.writeInt(cls);
    }

    public static class Handler implements IMessageHandler<PacketSync, IMessage> {
        @Override
        public IMessage onMessage(PacketSync msg, MessageContext ctx) {
            EntityPlayer p = SamuraiMod.proxy.getPlayer();
            if (p != null) {
                for (int i = 0; i < SkillData.COUNT; i++) SkillData.setLevel(p, i, msg.levels[i]);
                ProfileData.setProfile(p, msg.gender, msg.cls);
            }
            return null;
        }
    }
}
