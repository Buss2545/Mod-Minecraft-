package com.example.samurai;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;

/** /samurai chapter <0-6> : ข้ามไปตอนที่ต้องการ (ใช้ทดสอบ)   /samurai ngplus : เริ่ม NG+ ทันที */
public class CommandSamurai extends CommandBase {
    @Override
    public String getCommandName() { return "samurai"; }

    @Override
    public String getCommandUsage(ICommandSender sender) { return "/samurai chapter <0-6> | /samurai ngplus"; }

    @Override
    public int getRequiredPermissionLevel() { return 2; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        StoryProperties s = StoryProperties.get(p);
        if (s == null || args.length < 1) throw new WrongUsageException(getCommandUsage(sender), new Object[0]);

        if (args[0].equals("chapter") && args.length == 2) {
            s.chapter = parseIntBounded(sender, args[1], 0, StoryManager.total());
            s.zombieKills = 0;
            s.backup();
            s.showChapter(p);
        } else if (args[0].equals("ngplus")) {
            s.startNewGamePlus(p);
        } else {
            throw new WrongUsageException(getCommandUsage(sender), new Object[0]);
        }
    }
}
