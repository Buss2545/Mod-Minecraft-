package com.example.samurai;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;

/** ไคลเอนต์ส่งเพศและคลาสที่เลือก */
public class PacketCreate implements IMessage {
    public int gender, cls;

    public PacketCreate() {}
    public PacketCreate(int gender, int cls) { this.gender = gender; this.cls = cls; }

    @Override public void fromBytes(ByteBuf buf) { gender = buf.readInt(); cls = buf.readInt(); }
    @Override public void toBytes(ByteBuf buf) { buf.writeInt(gender); buf.writeInt(cls); }

    public static class Handler implements IMessageHandler<PacketCreate, IMessage> {
        @Override
        public IMessage onMessage(PacketCreate msg, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().playerEntity;
            final int g = msg.gender, c = msg.cls;
            // สร้างหมู่บ้าน/เสก NPC ต้องทำบนเธรดหลักของเซิร์ฟเวอร์
            TaskQueue.add(new Runnable() {
                @Override public void run() { ProfileData.create(p, g, c); }
            });
            return null;
        }
    }
}
