package com.example.samurai;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class KeyHandler {
    public static final KeyBinding SKILLS =
            new KeyBinding("key.samurai.skills", Keyboard.KEY_K, "key.categories.samurai");

    /** ตั้งเป็น true เมื่อเซิร์ฟเวอร์สั่งเปิดหน้าสร้างตัวละคร (packet มาจากเธรดเน็ตเวิร์ก จึงเปิดใน tick แทน) */
    public static volatile boolean openCreate = false;

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (SKILLS.isPressed() && mc.currentScreen == null && mc.thePlayer != null
                && ProfileData.isCreated(mc.thePlayer))
            mc.displayGuiScreen(new GuiSkills());
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !openCreate) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null && mc.currentScreen == null) {
            openCreate = false;
            mc.displayGuiScreen(new GuiCreateCharacter());
        }
    }
}
