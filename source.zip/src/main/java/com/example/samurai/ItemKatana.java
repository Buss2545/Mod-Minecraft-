package com.example.samurai;

import java.util.List;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class ItemKatana extends ItemSword {
    public ItemKatana(ToolMaterial material, String name) {
        super(material);
        setUnlocalizedName(name);
        setTextureName(SamuraiMod.MODID + ":" + name);
        setCreativeTab(CreativeTabs.tabCombat);
    }

    @Override
    public boolean hasEffect(ItemStack stack, int pass) { return true; }

    @Override
    public void onUpdate(ItemStack stack, World world, Entity holder, int slot, boolean held) {
        if (!held || !(world instanceof WorldServer) || !(holder instanceof EntityPlayer)) return;
        if (world.getTotalWorldTime() % 5 != 0) return;
        EntityPlayer p = (EntityPlayer) holder;
        Vec3 look = p.getLookVec();
        String type = SkillData.getLevel(p, SkillData.FLAME) > 0 ? "flame" : "magicCrit";
        ((WorldServer) world).func_147487_a(type,
                p.posX + look.xCoord * 0.8, p.posY + 1.1 + look.yCoord * 0.8, p.posZ + look.zCoord * 0.8,
                1, 0.15, 0.15, 0.15, 0.01);
    }

    // Shift + คลิกขวา = คลื่นดาบ, วิ่งแล้วคลิกขวา = พุ่งทะยาน, คลิกขวาค้าง = ตั้งการ์ด/ปัดป้อง
    @Override
    public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
        int wave = SkillData.getLevel(player, SkillData.WAVE);
        int dash = SkillData.getLevel(player, SkillData.DASH);
        boolean useWave = player.isSneaking() && wave > 0;
        boolean useDash = !useWave && dash > 0 && player.isSprinting();
        if (!useWave && !useDash) return super.onItemRightClick(stack, world, player);
        if (world.isRemote) return stack;

        if (useWave) castWave(world, player, wave);
        else castDash(world, player, dash);
        return stack;
    }

    private void castWave(World world, EntityPlayer player, int lv) {
        long now = world.getTotalWorldTime();
        if (now < SkillData.getWaveReady(player)) return;
        SkillData.setWaveReady(player, now + 60 - lv * 8); // คูลดาวน์ 2.6 วิ -> 1 วิ

        int flame = SkillData.getLevel(player, SkillData.FLAME);
        world.spawnEntityInWorld(new EntitySwordWave(world, player, 4.0F + lv * 2.0F, flame));
        world.playSoundAtEntity(player, "random.bow", 1.0F, 0.5F);
        player.swingItem();
    }

    private void castDash(World world, EntityPlayer player, int lv) {
        long now = world.getTotalWorldTime();
        if (now < SkillData.getDashReady(player)) return;
        int cd = 90 - lv * 12; // 3.9 วิ -> 1.5 วิ
        if (ProfileData.getClassId(player) == ProfileData.NINJA) cd = cd * 7 / 10;
        SkillData.setDashReady(player, now + cd);

        Vec3 look = player.getLookVec();
        double power = 1.0D + lv * 0.25D;
        player.motionX = look.xCoord * power;
        player.motionY = 0.2D + Math.max(0.0D, look.yCoord) * power * 0.5D;
        player.motionZ = look.zCoord * power;
        player.velocityChanged = true;
        player.fallDistance = 0.0F;

        List list = world.getEntitiesWithinAABBExcludingEntity(player,
                player.boundingBox.expand(1.5D, 0.5D, 1.5D).offset(look.xCoord * 2.5D, 0.0D, look.zCoord * 2.5D));
        for (Object o : list) {
            if (o instanceof EntityLivingBase && !(o instanceof EntityPlayer)) {
                ((EntityLivingBase) o).attackEntityFrom(DamageSource.causePlayerDamage(player), 3.0F + lv);
            }
        }

        if (world instanceof WorldServer)
            ((WorldServer) world).func_147487_a("cloud", player.posX, player.posY + 0.5, player.posZ,
                    15, 0.3, 0.2, 0.3, 0.05);
        world.playSoundAtEntity(player, "random.bow", 1.0F, 0.6F);
    }
}
