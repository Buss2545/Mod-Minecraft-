package com.example.samurai;

import java.util.List;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** หยกมะงะตะมะ: พกไว้ในช่องเก็บของแล้วฟื้นเลือดช้าๆ และทนไฟ (รางวัลจบตอนที่ 4) */
public class ItemMagatama extends Item {
    public ItemMagatama() {
        setUnlocalizedName("magatama");
        setTextureName(SamuraiMod.MODID + ":magatama");
        setCreativeTab(CreativeTabs.tabMisc);
        setMaxStackSize(1);
    }

    @Override
    public boolean hasEffect(ItemStack stack, int pass) { return true; }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean advanced) {
        list.add("พกไว้ในช่องเก็บของ: ฟื้นเลือด + ทนไฟ");
    }
}
