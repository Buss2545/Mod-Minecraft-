package com.example.samurai;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.WorldServer;

/**
 * ไทม์ไลน์ฝั่งเซิร์ฟเวอร์ของคัตซีน (ฝั่งไคลเอนต์วาดขอบดำ/คำบรรยาย/เครดิตใน CutsceneOverlay)
 * id 0 = จบตอนที่ 4 (ฆ่ายามาตะโนะโอโรจิ), id 1 = ฉากจบเกม (ฆ่า Ender Dragon)
 */
public class CutsceneManager {

    private static final int[] END = {300, 960};
    private static final double[] RADIUS = {48.0D, 80.0D};

    private static class Scene {
        final WorldServer world;
        final int id;
        final double x, y, z;
        final UUID killer;
        int t;

        Scene(WorldServer world, int id, double x, double y, double z, UUID killer) {
            this.world = world; this.id = id; this.x = x; this.y = y; this.z = z; this.killer = killer;
        }
    }

    private static final List<Scene> SCENES = new ArrayList<Scene>();

    /** เรียกฝั่งเซิร์ฟเวอร์ตอนบอสตาย */
    public static void start(EntityPlayer killer, int id, double x, double y, double z) {
        if (!(killer.worldObj instanceof WorldServer) || id < 0 || id >= END.length) return;
        SCENES.add(new Scene((WorldServer) killer.worldObj, id, x, y, z, killer.getUniqueID()));
    }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || SCENES.isEmpty()) return;
        Iterator<Scene> it = SCENES.iterator();
        while (it.hasNext()) {
            if (step(it.next())) it.remove();
        }
    }

    private List<EntityPlayerMP> nearby(Scene s) {
        double r = RADIUS[s.id];
        List<EntityPlayerMP> out = new ArrayList<EntityPlayerMP>();
        for (Object o : s.world.playerEntities) {
            if (o instanceof EntityPlayerMP && ((EntityPlayerMP) o).getDistanceSq(s.x, s.y, s.z) < r * r)
                out.add((EntityPlayerMP) o);
        }
        return out;
    }

    /** หาตัวผู้เล่นปัจจุบัน (กรณีตายแล้วเกิดใหม่ อ็อบเจกต์จะเปลี่ยน) */
    private EntityPlayerMP findKiller(Scene s) {
        for (Object o : MinecraftServer.getServer().getConfigurationManager().playerEntityList) {
            EntityPlayerMP p = (EntityPlayerMP) o;
            if (p.getUniqueID().equals(s.killer)) return p;
        }
        return null;
    }

    /** คืน true เมื่อจบฉาก */
    private boolean step(Scene s) {
        int t = s.t++;

        if (t == 0) {
            for (EntityPlayerMP p : nearby(s)) {
                NetworkHandler.NET.sendTo(new PacketCutscene(s.id), p);
                p.addPotionEffect(new PotionEffect(Potion.resistance.id, END[s.id] + 40, 4)); // กันโดนโจมตีระหว่างฉาก
            }
        }
        if (s.id == 0) stepOrochi(s, t); else stepEnding(s, t);

        if (t == END[s.id]) {
            EntityPlayerMP k = findKiller(s);
            if (k != null) {
                StoryProperties st = StoryProperties.get(k);
                if (st != null) {
                    if (s.id == 0) st.reward(k, 3); // ฉากจบเกมแจกรางวัลไปแล้วที่ t=330
                    st.showChapter(k);
                }
            }
            return true;
        }
        return false;
    }

    private void stepOrochi(Scene s, int t) {
        if (t == 10) {
            s.world.func_147487_a("hugeexplosion", s.x, s.y + 1.5, s.z, 1, 0.0, 0.0, 0.0, 0.0);
            s.world.playSoundEffect(s.x, s.y, s.z, "random.explode", 3.0F, 0.6F);
        } else if (t == 40 || t == 70 || t == 100) {
            s.world.func_147487_a("fireworksSpark", s.x, s.y + 2.0, s.z, 40, 0.6, 1.2, 0.6, 0.15);
        } else if (t == 130) {
            for (EntityPlayerMP p : nearby(s)) {
                p.worldObj.playSoundAtEntity(p, "random.levelup", 1.0F, 0.8F);
                p.heal(p.getMaxHealth());
                p.extinguish();
            }
        } else if (t == 200) {
            for (EntityPlayerMP p : nearby(s))
                s.world.func_147487_a("happyVillager", p.posX, p.posY + 1.0, p.posZ, 25, 0.6, 0.8, 0.6, 0.0);
        }
    }

    private void stepEnding(Scene s, int t) {
        if (t == 10) {
            s.world.func_147487_a("hugeexplosion", s.x, s.y + 2.0, s.z, 1, 0.0, 0.0, 0.0, 0.0);
            s.world.playSoundEffect(s.x, s.y, s.z, "random.explode", 4.0F, 0.5F);
        }
        if (t >= 40 && t <= 240 && t % 40 == 0)
            s.world.func_147487_a("fireworksSpark", s.x, s.y + 3.0, s.z, 60, 1.0, 1.5, 1.0, 0.2);

        if (t == 150) {
            // รุ่งอรุณในโลกปกติ ฟ้าแจ่มใส ตามเรื่อง "อาทิตย์อุทัยอีกครั้ง"
            WorldServer ow = MinecraftServer.getServer().worldServerForDimension(0);
            long now = ow.getWorldTime();
            ow.setWorldTime(now - now % 24000L + 24000L);
            ow.getWorldInfo().setRaining(false);
            ow.getWorldInfo().setThundering(false);
            for (EntityPlayerMP p : nearby(s))
                p.addChatMessage(new ChatComponentText("ท้องฟ้าทั่วแผ่นดินสว่างขึ้นอีกครั้ง..."));
        } else if (t == 300) {
            for (EntityPlayerMP p : nearby(s)) {
                p.worldObj.playSoundAtEntity(p, "random.levelup", 1.0F, 0.7F);
                p.heal(p.getMaxHealth());
                p.extinguish();
                s.world.func_147487_a("happyVillager", p.posX, p.posY + 1.0, p.posZ, 30, 0.7, 0.9, 0.7, 0.0);
            }
        } else if (t == 330) {
            EntityPlayerMP k = findKiller(s);
            if (k != null) {
                StoryProperties st = StoryProperties.get(k);
                if (st != null) st.reward(k, 5);
            }
        }
    }
}
