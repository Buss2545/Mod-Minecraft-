package com.example.samurai;

import java.util.Random;

import cpw.mods.fml.common.IWorldGenerator;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;

public class VillageGenerator implements IWorldGenerator {

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world,
                         IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.dimensionId != 0) return; // เฉพาะโลกปกติ
        if (random.nextInt(80) != 0) return;         // ความถี่ ปรับเลขได้

        // เริ่มที่ +8 จากมุมชังก์ เพื่อให้ทั้งโครงสร้างอยู่ในชังก์ที่เจนแล้ว
        int ox = chunkX * 16 + 8;
        int oz = chunkZ * 16 + 8;
        if (JapaneseVillage.canBuild(world, ox, oz)) {
            JapaneseVillage.build(world, ox, oz);
        }
    }
}
