package com.example.samurai;

import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityElder.class, new RenderNpc("elder"));
        RenderingRegistry.registerEntityRenderingHandler(EntityVillagerNpc.class, new RenderNpc("villager"));
        RenderingRegistry.registerEntityRenderingHandler(EntityOni.class, new RenderOni());
        RenderingRegistry.registerEntityRenderingHandler(EntityOrochi.class, new RenderOrochi());
        RenderingRegistry.registerEntityRenderingHandler(EntityOniKing.class, new RenderOniKing());
        RenderingRegistry.registerEntityRenderingHandler(EntitySwordWave.class, new RenderNothing());

        ClientRegistry.registerKeyBinding(KeyHandler.SKILLS);
        FMLCommonHandler.instance().bus().register(new KeyHandler());
        FMLCommonHandler.instance().bus().register(new SkinHandler());

        CutsceneOverlay overlay = new CutsceneOverlay();
        FMLCommonHandler.instance().bus().register(overlay); // tick
        MinecraftForge.EVENT_BUS.register(overlay);          // วาดทับหน้าจอ
    }

    @Override
    public EntityPlayer getPlayer() { return Minecraft.getMinecraft().thePlayer; }

    @Override
    public void requestCreateGui() { KeyHandler.openCreate = true; }

    @Override
    public void startCutscene(int id) { CutsceneOverlay.start(id); }
}
