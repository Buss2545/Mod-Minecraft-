package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.util.ResourceLocation;

@SideOnly(Side.CLIENT)
public class RenderOrochi extends RenderLiving {
    private static final ResourceLocation TEX =
            new ResourceLocation(SamuraiMod.MODID, "textures/entity/orochi.png");

    public RenderOrochi() {
        super(new ModelOrochi(), 2.0F);
    }

    @Override
    public void doRender(EntityLiving entity, double x, double y, double z, float yaw, float partial) {
        BossStatus.setBossStatus((IBossDisplayData) entity, true); // แถบเลือดบอสด้านบนจอ
        super.doRender(entity, x, y, z, yaw, partial);
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) { return TEX; }
}
