package com.example.samurai;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

public class SkillEvents {

    @SubscribeEvent
    public void onHurt(LivingHurtEvent e) {
        // ผู้เล่นเป็นฝ่ายโดนตี: สกิลผิวเหล็ก + โบนัสนักบวช
        if (e.entityLiving instanceof EntityPlayer) {
            EntityPlayer v = (EntityPlayer) e.entityLiving;
            float mul = 1.0F - 0.06F * SkillData.getLevel(v, SkillData.GUARD);
            if (ProfileData.getClassId(v) == ProfileData.PRIEST) mul *= 0.85F;
            e.ammount *= mul;
        }

        // ผู้เล่นเป็นฝ่ายตีด้วยดาบ
        if (!(e.source.getSourceOfDamage() instanceof EntityPlayer)) return;
        EntityPlayer p = (EntityPlayer) e.source.getSourceOfDamage();
        ItemStack held = p.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemKatana)) return;

        int sharp = SkillData.getLevel(p, SkillData.SHARP);
        int flame = SkillData.getLevel(p, SkillData.FLAME);

        e.ammount += sharp + (ProfileData.getClassId(p) == ProfileData.SAMURAI ? 1 : 0);
        EntityLivingBase t = e.entityLiving;
        if (flame > 0) t.setFire(2 * flame + 1);

        if (p.worldObj instanceof WorldServer) {
            WorldServer ws = (WorldServer) p.worldObj;
            double y = t.posY + t.height / 2;
            ws.func_147487_a("crit", t.posX, y, t.posZ, 12, 0.3, 0.4, 0.3, 0.2);
            if (flame > 0)
                ws.func_147487_a("flame", t.posX, y, t.posZ, 6 + flame * 3, 0.3, 0.4, 0.3, 0.03);
        }
    }

    // นินจาตกจากที่สูงไม่เจ็บ
    @SubscribeEvent
    public void onFall(LivingFallEvent e) {
        if (e.entityLiving instanceof EntityPlayer
                && ProfileData.getClassId((EntityPlayer) e.entityLiving) == ProfileData.NINJA)
            e.setCanceled(true);
    }

    // นักบวชฟื้นเลือด 1 ทุก 5 วินาที (ถ้าไม่หิวมาก)
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.worldObj.isRemote) return;
        EntityPlayer p = e.player;
        if (p.ticksExisted % 100 == 0 && ProfileData.getClassId(p) == ProfileData.PRIEST
                && p.getHealth() < p.getMaxHealth() && p.getFoodStats().getFoodLevel() > 6)
            p.heal(1.0F);

        // หยกมะงะตะมะในช่องเก็บของ: ฟื้นเลือด + ทนไฟ
        if (p.ticksExisted % 40 == 0 && p.inventory.hasItem(SamuraiMod.magatama)) {
            p.addPotionEffect(new PotionEffect(Potion.regeneration.id, 100, 0));
            p.addPotionEffect(new PotionEffect(Potion.fireResistance.id, 100, 0));
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        ProfileData.applyClass(e.player);
        SkillData.sync(e.player);
        if (!ProfileData.isCreated(e.player) && e.player instanceof EntityPlayerMP)
            NetworkHandler.NET.sendTo(new PacketOpenCreate(), (EntityPlayerMP) e.player);
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        ProfileData.applyClass(e.player);
        e.player.setHealth(e.player.getMaxHealth());
        SkillData.sync(e.player);
    }

    @SubscribeEvent
    public void onDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        ProfileData.applyClass(e.player);
        SkillData.sync(e.player);
    }
}
