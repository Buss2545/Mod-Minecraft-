package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderOni extends RenderBiped {
    private static final ResourceLocation TEX =
            new ResourceLocation(SamuraiMod.MODID, "textures/entity/oni.png");

    public RenderOni() {
        super(new ModelOni(), 0.8F);
    }

    @Override
    protected void preRenderCallback(EntityLivingBase e, float partial) {
        GL11.glScalef(1.3F, 1.3F, 1.3F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLiving entity) { return TEX; }
}
