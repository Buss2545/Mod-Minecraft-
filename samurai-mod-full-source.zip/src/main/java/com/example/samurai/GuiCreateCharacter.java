package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** หน้าเลือกเพศและคลาส เปิดครั้งแรกที่เข้าเกม ปิดด้วย ESC ไม่ได้ */
@SideOnly(Side.CLIENT)
public class GuiCreateCharacter extends GuiScreen {
    private static final int W = 240, H = 210;
    private int gender = -1, cls = -1;
    private int left, top;

    @Override
    public void initGui() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        buttonList.clear();
        buttonList.add(new GuiButton(0, left + 20, top + 44, 95, 20, ""));
        buttonList.add(new GuiButton(1, left + 125, top + 44, 95, 20, ""));
        for (int i = 0; i < ProfileData.CLASS_NAMES.length; i++)
            buttonList.add(new GuiButton(10 + i, left + 20, top + 86 + i * 24, 200, 20, ""));
        buttonList.add(new GuiButton(99, left + 60, top + H - 28, 120, 20, "เริ่มการเดินทาง"));
        refresh();
    }

    private void refresh() {
        for (Object o : buttonList) {
            GuiButton b = (GuiButton) o;
            if (b.id < 2) {
                b.displayString = (gender == b.id ? "> " : "") + ProfileData.GENDERS[b.id];
            } else if (b.id == 99) {
                b.enabled = gender >= 0 && cls >= 0;
            } else {
                int c = b.id - 10;
                b.displayString = (cls == c ? "> " : "") + ProfileData.CLASS_NAMES[c];
            }
        }
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        if (b.id < 2) {
            gender = b.id;
        } else if (b.id == 99) {
            NetworkHandler.NET.sendToServer(new PacketCreate(gender, cls));
            mc.displayGuiScreen(null);
            return;
        } else {
            cls = b.id - 10;
        }
        refresh();
    }

    @Override
    protected void keyTyped(char c, int key) {
        // ไม่ให้ปิดหน้าต่างด้วย ESC ต้องเลือกก่อน
    }

    @Override
    public void drawScreen(int mx, int my, float partial) {
        drawDefaultBackground();
        drawRect(left - 2, top - 2, left + W + 2, top + H + 2, 0xFFB22222);
        drawRect(left, top, left + W, top + H, 0xF0202030);

        drawCenteredString(fontRendererObj, "สร้างตัวละคร", left + W / 2, top + 8, 0xFFD700);
        drawCenteredString(fontRendererObj, "เลือกแล้วเปลี่ยนภายหลังไม่ได้", left + W / 2, top + 20, 0xAAAAAA);
        fontRendererObj.drawString("เพศ", left + 20, top + 33, 0xFFFFFF);
        fontRendererObj.drawString("อาชีพ", left + 20, top + 75, 0xFFFFFF);

        if (cls >= 0)
            fontRendererObj.drawSplitString(ProfileData.CLASS_DESCS[cls], left + 20, top + 162, W - 40, 0x80FF20);

        super.drawScreen(mx, my, partial);
    }

    @Override
    public boolean doesGuiPauseGame() { return true; }
}
