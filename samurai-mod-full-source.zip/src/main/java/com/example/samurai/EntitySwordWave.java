package com.example.samurai;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** คลื่นดาบ: พุ่งตรงไม่ตก ชนอะไรก็ระเบิดดาเมจรอบๆ */
public class EntitySwordWave extends EntityThrowable {
    private float damage;
    private int fireLevel;
    private int life;

    public EntitySwordWave(World world) {
        super(world);
    }

    public EntitySwordWave(World world, EntityLivingBase thrower, float damage, int fireLevel) {
        super(world, thrower);
        this.damage = damage;
        this.fireLevel = fireLevel;
        Vec3 look = thrower.getLookVec();
        setThrowableHeading(look.xCoord, look.yCoord, look.zCoord, 1.6F, 0.0F);
    }

    @Override
    protected float getGravityVelocity() { return 0.0F; }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (worldObj.isRemote) return;
        if (damage <= 0.0F || ++life > 25) { setDead(); return; }
        ((WorldServer) worldObj).func_147487_a(fireLevel > 0 ? "flame" : "crit",
                posX, posY, posZ, 5, 0.4, 0.25, 0.4, 0.02);
        ((WorldServer) worldObj).func_147487_a("magicCrit", posX, posY, posZ, 2, 0.3, 0.2, 0.3, 0.01);
    }

    @Override
    protected void onImpact(MovingObjectPosition mop) {
        if (worldObj.isRemote) return;
        EntityLivingBase owner = getThrower();
        List list = worldObj.getEntitiesWithinAABB(EntityLivingBase.class, boundingBox.expand(1.5D, 1.0D, 1.5D));
        for (Object o : list) {
            if (o == owner || o instanceof EntityNpc) continue;
            EntityLivingBase t = (EntityLivingBase) o;
            t.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), damage);
            if (fireLevel > 0) t.setFire(2 * fireLevel + 1);
        }
        ((WorldServer) worldObj).func_147487_a("explode", posX, posY, posZ, 6, 0.4, 0.4, 0.4, 0.05);
        setDead();
    }
}
