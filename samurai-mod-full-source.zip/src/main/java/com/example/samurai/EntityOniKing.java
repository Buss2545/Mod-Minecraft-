package com.example.samurai;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** โอนิราชา: บอสกลางเรื่องตอนที่ 2 ตัวใหญ่ ทุบพื้นสะบัดผู้เล่น เลือดต่ำกว่าครึ่งจะเรียกโอนิมาช่วย */
public class EntityOniKing extends EntityOni implements IBossDisplayData {
    private boolean enraged;
    private int slamCooldown = 80;

    public EntityOniKing(World world) {
        super(world);
        setSize(1.4F, 3.4F);
        experienceValue = 150;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(120.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(9.0D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
        getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.8D);
    }

    @Override
    protected boolean canDespawn() { return false; }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        dropItem(SamuraiMod.kanabo, 1);
        dropItem(Items.gold_ingot, 4 + rand.nextInt(4));
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (worldObj.isRemote) return;

        EntityLivingBase target = getAttackTarget();
        if (target == null) return;

        if (!enraged && getHealth() < getMaxHealth() * 0.5F) enrage();

        if (--slamCooldown <= 0 && getDistanceSqToEntity(target) < 36.0D) {
            slamCooldown = enraged ? 70 : 110;
            slam();
        }
    }

    /** ทุบพื้น: ดาเมจและสะบัดผู้เล่นรอบตัวในรัศมี 5 บล็อก */
    private void slam() {
        worldObj.playSoundAtEntity(this, "random.explode", 2.0F, 0.7F);
        ((WorldServer) worldObj).func_147487_a("explode", posX, posY + 0.2, posZ, 30, 2.0, 0.1, 2.0, 0.05);
        List list = worldObj.getEntitiesWithinAABB(EntityPlayer.class, boundingBox.expand(5.0D, 1.5D, 5.0D));
        for (Object o : list) {
            EntityPlayer p = (EntityPlayer) o;
            p.attackEntityFrom(DamageSource.causeMobDamage(this), 6.0F);
            double dx = p.posX - posX, dz = p.posZ - posZ;
            double len = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
            p.addVelocity(dx / len * 1.3D, 0.7D, dz / len * 1.3D);
            p.velocityChanged = true;
        }
    }

    private void enrage() {
        enraged = true;
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.36D);
        for (int i = 0; i < 2; i++) {
            EntityOni oni = new EntityOni(worldObj);
            oni.setLocationAndAngles(posX + (i == 0 ? 3.0D : -3.0D), posY, posZ + 2.0D, rand.nextFloat() * 360.0F, 0.0F);
            worldObj.spawnEntityInWorld(oni);
        }
        worldObj.playSoundAtEntity(this, "mob.wither.spawn", 2.0F, 1.0F);
        List players = worldObj.getEntitiesWithinAABB(EntityPlayer.class, boundingBox.expand(30.0D, 15.0D, 30.0D));
        for (Object o : players)
            ((EntityPlayer) o).addChatMessage(new ChatComponentText("โอนิราชาคำรามลั่น! ลูกสมุนมาแล้ว!"));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setBoolean("Enraged", enraged);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        enraged = tag.getBoolean("Enraged");
    }

    /** เรียกโอนิราชาข้างผู้เล่น (หาจุดว่างรอบตัวในรัศมี 6 บล็อก) */
    public static void summonNear(EntityPlayer p) {
        World w = p.worldObj;
        EntityOniKing king = new EntityOniKing(w);
        boolean placed = false;
        for (int i = 0; i < 8 && !placed; i++) {
            double ang = Math.toRadians(p.rotationYaw + 90.0D + i * 45.0D);
            double x = p.posX + Math.cos(ang) * 6.0D;
            double z = p.posZ + Math.sin(ang) * 6.0D;
            king.setLocationAndAngles(x, p.posY, z, p.rotationYaw + 180.0F, 0.0F);
            placed = w.getCollidingBoundingBoxes(king, king.boundingBox).isEmpty()
                    && !w.isAnyLiquid(king.boundingBox);
        }
        if (!placed) king.setLocationAndAngles(p.posX, p.posY + 1.0D, p.posZ + 3.0D, 0.0F, 0.0F);
        StoryProperties st = StoryProperties.get(p);
        if (st != null) NgPlus.scale(king, st.ng); // NG+: บอสแกร่งขึ้น
        w.spawnEntityInWorld(king);
        w.playSoundAtEntity(king, "mob.wither.spawn", 2.0F, 0.9F);
        p.addChatMessage(new ChatComponentText("โอนิราชาปรากฏตัวขึ้นมาแล้ว!"));
    }
}
