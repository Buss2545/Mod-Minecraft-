package com.example.samurai;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;

/** รันงานบนเธรดหลักของเซิร์ฟเวอร์ (packet handler รันบนเธรดเน็ตเวิร์ก ห้ามแตะโลกตรงๆ) */
public class TaskQueue {
    private static final Queue<Runnable> QUEUE = new ConcurrentLinkedQueue<Runnable>();

    public static void add(Runnable r) { QUEUE.add(r); }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Runnable r;
        while ((r = QUEUE.poll()) != null) r.run();
    }
}
