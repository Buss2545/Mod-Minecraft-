package com.example.samurai;

import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;

public class NetworkHandler {
    public static final SimpleNetworkWrapper NET =
            NetworkRegistry.INSTANCE.newSimpleChannel("samuraimod");

    public static void init() {
        NET.registerMessage(PacketUpgrade.Handler.class, PacketUpgrade.class, 0, Side.SERVER);
        NET.registerMessage(PacketSync.Handler.class, PacketSync.class, 1, Side.CLIENT);
        NET.registerMessage(PacketCreate.Handler.class, PacketCreate.class, 2, Side.SERVER);
        NET.registerMessage(PacketOpenCreate.Handler.class, PacketOpenCreate.class, 3, Side.CLIENT);
        NET.registerMessage(PacketCutscene.Handler.class, PacketCutscene.class, 4, Side.CLIENT);
    }
}
