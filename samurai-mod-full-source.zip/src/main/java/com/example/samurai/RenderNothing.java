package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

/** entity ที่ไม่ต้องวาดโมเดล (ใช้อนุภาคจากเซิร์ฟเวอร์แทน) */
@SideOnly(Side.CLIENT)
public class RenderNothing extends Render {
    @Override
    public void doRender(Entity e, double x, double y, double z, float yaw, float partial) {}

    @Override
    protected ResourceLocation getEntityTexture(Entity e) { return null; }
}
