package com.example.samurai;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;

/** เซิร์ฟเวอร์สั่งให้ไคลเอนต์เปิดหน้าสร้างตัวละคร */
public class PacketOpenCreate implements IMessage {
    @Override public void fromBytes(ByteBuf buf) {}
    @Override public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<PacketOpenCreate, IMessage> {
        @Override
        public IMessage onMessage(PacketOpenCreate msg, MessageContext ctx) {
            SamuraiMod.proxy.requestCreateGui();
            return null;
        }
    }
}
