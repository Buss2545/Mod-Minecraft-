package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class RenderOniKing extends RenderBiped {
    private static final ResourceLocation TEX =
            new ResourceLocation(SamuraiMod.MODID, "textures/entity/oni_king.png");

    public RenderOniKing() {
        super(new ModelBiped(), 1.4F);
    }

    @Override
    protected void preRenderCallback(EntityLivingBase e, float partial) {
        GL11.glScalef(1.8F, 1.8F, 1.8F);
    }

    @Override
    public void doRender(EntityLiving entity, double x, double y, double z, float yaw, float partial) {
        BossStatus.setBossStatus((IBossDisplayData) entity, true);
        super.doRender(entity, x, y, z, yaw, partial);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLiving entity) { return TEX; }
}
