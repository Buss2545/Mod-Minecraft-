package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/** โมเดลงูแปดหัว (texture 256x128: ลำตัว 0,0 / หาง 0,80 / คอ 204,0 / หัว 204,30) */
@SideOnly(Side.CLIENT)
public class ModelOrochi extends ModelBase {
    private static final int HEADS = 8;
    private static final float[] NX = {-14F, 0F, 14F, -17F, 17F, -10F, 10F, 0F};
    private static final float[] NZ = {-20F, -24F, -20F, -4F, -4F, 14F, 14F, 4F};

    private final ModelRenderer body;
    private final ModelRenderer tail;
    private final ModelRenderer[] necks = new ModelRenderer[HEADS];
    private final ModelRenderer[] heads = new ModelRenderer[HEADS];

    public ModelOrochi() {
        textureWidth = 256;
        textureHeight = 128;

        body = new ModelRenderer(this, 0, 0);
        body.addBox(-22F, -22F, -28F, 44, 22, 56);
        body.setRotationPoint(0F, 22F, 0F);

        tail = new ModelRenderer(this, 0, 80);
        tail.addBox(-7F, -6F, 0F, 14, 12, 36);
        tail.setRotationPoint(0F, 14F, 26F);

        for (int i = 0; i < HEADS; i++) {
            int len = 22 + 4 * (i % 3);

            necks[i] = new ModelRenderer(this, 204, 0);
            necks[i].addBox(-2F, -len, -2F, 4, len, 4);
            necks[i].setRotationPoint(NX[i], 2F, NZ[i]);

            heads[i] = new ModelRenderer(this, 204, 30);
            heads[i].addBox(-5F, -4F, -12F, 10, 8, 14);
            heads[i].setRotationPoint(0F, -len, 0F);

            necks[i].addChild(heads[i]);
        }
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        body.render(f5);
        tail.render(f5);
        for (int i = 0; i < HEADS; i++) necks[i].render(f5);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age,
                                  float yaw, float pitch, float scale, Entity entity) {
        for (int i = 0; i < HEADS; i++) {
            float phase = age * 0.07F + i * 0.8F;
            necks[i].rotateAngleX = 0.15F + MathHelper.sin(phase) * 0.15F;
            necks[i].rotateAngleZ = NX[i] * 0.012F + MathHelper.cos(phase * 0.8F) * 0.12F;
            heads[i].rotateAngleX = 0.35F + MathHelper.sin(phase + 1.0F) * 0.12F;
        }
        tail.rotateAngleY = MathHelper.sin(age * 0.05F) * 0.35F;
    }
}
