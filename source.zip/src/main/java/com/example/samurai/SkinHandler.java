package com.example.samurai;

import java.lang.reflect.Field;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.ReflectionHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.util.ResourceLocation;

/**
 * เปลี่ยนสกินผู้เล่นตามเพศ+คลาส (เห็นทั้งตัวเองและผู้เล่นคนอื่น รวมมือในมุมมองบุคคลที่ 1)
 * สกินเป็นไฟล์ 64x32 ตามรูปแบบของ Minecraft 1.7.10 (ไม่มีชั้นนอกของ 64x64 และไม่มีแขนแบบ slim)
 */
@SideOnly(Side.CLIENT)
public class SkinHandler {
    private static final ResourceLocation[][] SKINS = new ResourceLocation[3][2];
    private static Field skinField;
    private static boolean failed;

    static {
        for (int c = 0; c < 3; c++)
            for (int g = 0; g < 2; g++)
                SKINS[c][g] = new ResourceLocation(SamuraiMod.MODID, "textures/skins/" + c + "_" + g + ".png");
        try {
            // 1.7.10: AbstractClientPlayer.locationSkin (SRG: field_110312_d)
            skinField = ReflectionHelper.findField(AbstractClientPlayer.class, "locationSkin", "field_110312_d");
        } catch (Exception ex) {
            failed = true; // หาฟิลด์ไม่เจอ: ปิดระบบสกิน เกมยังเล่นได้ปกติ
        }
    }

    /**
     * อ่านค่า (เพศ << 8 | คลาส) ของผู้เล่น คืน -1 ถ้ายังไม่ทราบ
     * ใน 1.7.10 เมื่อเปลี่ยนมิติ/เกิดใหม่ ไคลเอนต์จะสร้างตัวผู้เล่นใหม่ที่มี DataWatcher ว่าง
     * แต่เซิร์ฟเวอร์ไม่ส่งค่าซ้ำถ้าค่าไม่เปลี่ยน สกินตัวเองจึงหลุดกลับเป็นสกินปกติ
     * จึงใช้ข้อมูลโปรไฟล์ที่ PacketSync ส่งมา เป็นตัวสำรองสำหรับผู้เล่นฝั่งเรา
     */
    private static int readCode(AbstractClientPlayer p, boolean isLocal) {
        int v = -1;
        try {
            v = p.getDataWatcher().getWatchableObjectInt(ProfileData.WATCHER_ID);
        } catch (Exception ex) {
            // ไม่มีช่อง DataWatcher นี้ (ถูกม็อดอื่นใช้ไปก่อน) ข้ามไปใช้ตัวสำรอง
        }
        if (v < 0 && isLocal) {
            int c = ProfileData.getClassId(p);
            if (c >= 0) v = (ProfileData.getGender(p) << 8) | c;
        }
        return v;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || failed) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;

        for (Object o : mc.theWorld.playerEntities) {
            if (!(o instanceof AbstractClientPlayer)) continue;
            AbstractClientPlayer p = (AbstractClientPlayer) o;

            int v = readCode(p, p == mc.thePlayer);
            if (v < 0) continue;
            int cls = v & 255, gender = v >> 8;
            if (cls >= SKINS.length || gender < 0 || gender >= SKINS[0].length) continue;

            try {
                ResourceLocation want = SKINS[cls][gender];
                // ตั้งซ้ำทุก tick เพราะสกินจริงโหลดมาทับได้ภายหลัง (เซ็ตเฉพาะเมื่อไม่ตรง)
                if (skinField.get(p) != want) skinField.set(p, want);
            } catch (Exception ex) {
                failed = true;
            }
        }
    }
}
