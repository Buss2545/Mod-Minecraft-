package com.example.samurai;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.EnumHelper;

@Mod(modid = SamuraiMod.MODID, name = "Samurai Legend", version = "1.2", acceptedMinecraftVersions = "[1.7.10]")
public class SamuraiMod {
    public static final String MODID = "samuraimod";

    @Instance(MODID)
    public static SamuraiMod instance;

    @SidedProxy(clientSide = "com.example.samurai.ClientProxy",
                serverSide = "com.example.samurai.CommonProxy")
    public static CommonProxy proxy;

    public static Item katana;
    public static Item kusanagi;
    public static Item scroll;
    public static Item sakeOffering;
    public static Item magatama;
    public static Item kanabo;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Item.ToolMaterial katanaMat = EnumHelper.addToolMaterial("KATANA", 2, 800, 7.0F, 3.0F, 12);
        Item.ToolMaterial kusanagiMat = EnumHelper.addToolMaterial("KUSANAGI", 3, 2500, 9.0F, 5.0F, 18);

        katana = new ItemKatana(katanaMat, "katana");
        kusanagi = new ItemKatana(kusanagiMat, "kusanagi");
        scroll = new ItemStoryScroll();
        sakeOffering = new ItemSakeOffering();
        magatama = new ItemMagatama();
        kanabo = new ItemKanabo(EnumHelper.addToolMaterial("KANABO", 2, 1200, 5.0F, 4.0F, 8));
        GameRegistry.registerItem(katana, "katana");
        GameRegistry.registerItem(kusanagi, "kusanagi");
        GameRegistry.registerItem(scroll, "story_scroll");
        GameRegistry.registerItem(sakeOffering, "sake_offering");
        GameRegistry.registerItem(magatama, "magatama");
        GameRegistry.registerItem(kanabo, "kanabo");

        GameRegistry.addShapedRecipe(new ItemStack(katana),
                "  I", " I ", "S  ",
                'I', Items.iron_ingot, 'S', Items.stick);

        // เครื่องบูชาสาเก: เนเธอร์วอร์ต 8 ล้อมทอง 1
        GameRegistry.addShapedRecipe(new ItemStack(sakeOffering),
                "WWW", "WGW", "WWW",
                'W', Items.nether_wart, 'G', Items.gold_ingot);

        NetworkHandler.init();

        // ----- entity -----
        int id1 = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(EntityElder.class, "SamuraiElder", id1, 0x6B4A2B, 0xE8E0D0);
        EntityRegistry.registerModEntity(EntityElder.class, "SamuraiElder", 0, this, 64, 3, true);

        int id2 = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(EntityVillagerNpc.class, "SamuraiVillager", id2, 0x3A5F3A, 0xD9B98A);
        EntityRegistry.registerModEntity(EntityVillagerNpc.class, "SamuraiVillager", 1, this, 64, 3, true);

        int id3 = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(EntityOni.class, "SamuraiOni", id3, 0x8B0000, 0x222222);
        EntityRegistry.registerModEntity(EntityOni.class, "SamuraiOni", 2, this, 64, 3, true);
        EntityRegistry.addSpawn(EntityOni.class, 10, 1, 3, EnumCreatureType.monster,
                BiomeGenBase.plains, BiomeGenBase.forest, BiomeGenBase.taiga,
                BiomeGenBase.extremeHills, BiomeGenBase.swampland);

        int id4 = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(EntityOrochi.class, "SamuraiOrochi", id4, 0x1B4D2B, 0xB22222);
        EntityRegistry.registerModEntity(EntityOrochi.class, "SamuraiOrochi", 3, this, 80, 3, true);

        int id5 = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(EntityOniKing.class, "SamuraiOniKing", id5, 0x6E0F0F, 0xE0B040);
        EntityRegistry.registerModEntity(EntityOniKing.class, "SamuraiOniKing", 5, this, 64, 3, true);

        EntityRegistry.registerModEntity(EntitySwordWave.class, "SamuraiSwordWave", 4, this, 64, 1, true);

        GameRegistry.registerWorldGenerator(new VillageGenerator(), 5);
        proxy.registerRenderers();

        // ----- events -----
        StoryEvents events = new StoryEvents();
        MinecraftForge.EVENT_BUS.register(events);
        FMLCommonHandler.instance().bus().register(events);

        SkillEvents skillEvents = new SkillEvents();
        MinecraftForge.EVENT_BUS.register(skillEvents);
        FMLCommonHandler.instance().bus().register(skillEvents);

        FMLCommonHandler.instance().bus().register(new TaskQueue());
        FMLCommonHandler.instance().bus().register(new CutsceneManager());
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSamurai());
    }
}
