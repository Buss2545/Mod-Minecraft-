package com.example.samurai;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class JapaneseVillage {

    // ชาวบ้าน 3 คน: ชาวนา / ผู้ดูแลศาลเจ้า / ทหารยาม (พิกัดสัมพัทธ์จากมุมหมู่บ้าน)
    private static final int[] PROF = {EntityVillagerNpc.FARMER, EntityVillagerNpc.PRIEST, EntityVillagerNpc.GUARD};
    private static final double[] HOME_X = {3.5, 13.5, 7.5}, HOME_Z = {8.5, 8.5, 13.5};
    private static final double[] WORK_X = {2.5, 8.5, 7.5},  WORK_Z = {4.5, 9.5, 2.5};

    private static void set(World w, int x, int y, int z, Block b, int meta) {
        w.setBlock(x, y, z, b, meta, 2);
    }

    private static void red(World w, int x, int y, int z)   { set(w, x, y, z, Blocks.stained_hardened_clay, 14); }
    private static void black(World w, int x, int y, int z) { set(w, x, y, z, Blocks.stained_hardened_clay, 15); }

    /** เช็กว่าพื้นที่ 16x16 เรียบพอและไม่ใช่น้ำ */
    public static boolean canBuild(World w, int ox, int oz) {
        int min = 255, max = 0;
        int[][] pts = {{0, 0}, {15, 0}, {0, 15}, {15, 15}, {8, 8}};
        for (int[] p : pts) {
            int x = ox + p[0], z = oz + p[1];
            int y = w.getTopSolidOrLiquidBlock(x, z);
            if (w.getBlock(x, y - 1, z).getMaterial().isLiquid()) return false;
            min = Math.min(min, y);
            max = Math.max(max, y);
        }
        return max - min <= 4;
    }

    public static void build(World w, int ox, int oz) {
        int y = w.getTopSolidOrLiquidBlock(ox + 8, oz + 8);

        // 1) ปรับพื้นที่ให้เรียบ
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = ox + lx, z = oz + lz;
                for (int dy = -8; dy <= -2; dy++) set(w, x, y + dy, z, Blocks.dirt, 0);
                boolean path = (lx == 7 || lx == 8);
                set(w, x, y - 1, z, path ? Blocks.cobblestone : Blocks.grass, 0);
                for (int dy = 0; dy <= 10; dy++) set(w, x, y + dy, z, Blocks.air, 0);
            }
        }

        // 2) ประตูโทริอิ (ที่ lz = 1)
        int tz = oz + 1;
        for (int dy = 0; dy <= 4; dy++) {
            red(w, ox + 5, y + dy, tz);
            red(w, ox + 10, y + dy, tz);
        }
        for (int lx = 5; lx <= 10; lx++) red(w, ox + lx, y + 3, tz);
        for (int lx = 3; lx <= 12; lx++) black(w, ox + lx, y + 5, tz);

        // 3) โคมหิน
        int[] lanternX = {6, 9};
        for (int lx : lanternX) {
            set(w, ox + lx, y, oz + 3, Blocks.cobblestone_wall, 0);
            set(w, ox + lx, y + 1, oz + 3, Blocks.glowstone, 0);
        }

        // 4) แปลงนาของชาวนา (x 1-4, z 2-3)
        for (int lx = 1; lx <= 4; lx++) {
            for (int lz = 2; lz <= 3; lz++) {
                set(w, ox + lx, y - 1, oz + lz, Blocks.farmland, 7);
                set(w, ox + lx, y, oz + lz, Blocks.wheat, 7);
            }
        }

        // 5) บ้านสองหลัง + ศาลเจ้า (door: 0=เหนือ 1=ใต้ 2=ตะวันตก 3=ตะวันออก)
        house(w, ox + 0,  y, oz + 5,  6, 6, 3, 3);
        house(w, ox + 10, y, oz + 5,  6, 6, 3, 2);
        house(w, ox + 3,  y, oz + 11, 10, 5, 4, 0);

        // 6) ชาวบ้านพร้อมกิจวัตร
        for (int i = 0; i < 3; i++) {
            EntityVillagerNpc npc = new EntityVillagerNpc(w);
            npc.setLocationAndAngles(ox + 7.0D + i, y, oz + 8.0D, 0.0F, 0.0F);
            npc.setRoutine(PROF[i],
                    ox + HOME_X[i], y, oz + HOME_Z[i],
                    ox + WORK_X[i], y, oz + WORK_Z[i],
                    ox + 8.0D, oz + 7.5D);
            w.spawnEntityInWorld(npc);
        }
    }

    private static void house(World w, int x0, int y, int z0, int sx, int sz, int h, int door) {
        int x1 = x0 + sx - 1, z1 = z0 + sz - 1;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                set(w, x, y - 1, z, Blocks.planks, 1);

                boolean edge = (x == x0 || x == x1 || z == z0 || z == z1);
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);
                if (!edge) continue;

                for (int dy = 0; dy < h; dy++) {
                    if (corner) {
                        set(w, x, y + dy, z, Blocks.log, 1);
                    } else if (dy == 1 && (x + z) % 2 == 0) {
                        set(w, x, y + dy, z, Blocks.glass_pane, 0);
                    } else {
                        set(w, x, y + dy, z, Blocks.planks, 2);
                    }
                }
            }
        }

        int dx, dz;
        switch (door) {
            case 0:  dx = x0 + sx / 2; dz = z0; break;
            case 1:  dx = x0 + sx / 2; dz = z1; break;
            case 2:  dx = x0;          dz = z0 + sz / 2; break;
            default: dx = x1;          dz = z0 + sz / 2; break;
        }
        set(w, dx, y, dz, Blocks.air, 0);
        set(w, dx, y + 1, dz, Blocks.air, 0);

        set(w, x0 + 1, y, z0 + 1, Blocks.torch, 5);

        int rx0 = x0, rx1 = x1, rz0 = z0, rz1 = z1, ry = y + h;
        while (rx0 <= rx1 && rz0 <= rz1) {
            for (int x = rx0; x <= rx1; x++)
                for (int z = rz0; z <= rz1; z++)
                    set(w, x, ry, z, Blocks.planks, 5);
            rx0++; rx1--; rz0++; rz1--; ry++;
        }
    }
}
