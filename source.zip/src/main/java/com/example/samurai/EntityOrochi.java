package com.example.samurai;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** ยามาตะโนะโอโรจิ: งูแปดหัว บอสตอนที่ 4 */
public class EntityOrochi extends EntityMob implements IBossDisplayData {
    /** สถานะแอนิเมชัน (DataWatcher ช่อง 20, บิต 16 = คลั่ง): 0 ปกติ 1 ถอยหัวเตรียมพ่นไฟ 2 ง้างหาง 3 หางฟาด 4 พ่นไฟ */
    public static final int ST_IDLE = 0, ST_REAR = 1, ST_TAIL_WIND = 2, ST_TAIL_HIT = 3, ST_FIRE = 4;

    /** ค่าแอนิเมชันฝั่งไคลเอนต์ 0..1 (ModelOrochi อ่านไปใช้) */
    public float rear, fire, lash, snap;

    private boolean enraged;
    private int volley, volleyDelay, breathCooldown = 100;
    private int fireWindup, tailWindup, strikeHold, tailCooldown = 80;

    public EntityOrochi(World world) {
        super(world);
        setSize(3.5F, 3.5F);
        isImmuneToFire = true;
        experienceValue = 500;
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
        tasks.addTask(2, new EntityAIWander(this, 0.6D));
        tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 32.0F));
        tasks.addTask(4, new EntityAILookIdle(this));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
    }

    @Override
    public boolean isAIEnabled() { return true; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(300.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.30D);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(10.0D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
        getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(1.0D);
    }

    @Override
    protected boolean canDespawn() { return false; }

    @Override protected String getLivingSound() { return "mob.wither.idle"; }
    @Override protected String getHurtSound()   { return "mob.wither.hurt"; }
    @Override protected String getDeathSound()  { return "mob.wither.death"; }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        dropItem(SamuraiMod.kusanagi, 1); // ดาบคุซานางิในหางงู ตามตำนาน
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataWatcher.addObject(20, Byte.valueOf((byte) 0));
    }

    public int getAnimState() { return dataWatcher.getWatchableObjectByte(20) & 15; }

    public boolean isEnragedClient() { return (dataWatcher.getWatchableObjectByte(20) & 16) != 0; }

    private void setState(int s) {
        dataWatcher.updateObject(20, Byte.valueOf((byte) (s | (enraged ? 16 : 0))));
    }

    private static float approach(float v, float target, float step) {
        return v < target ? Math.min(target, v + step) : Math.max(target, v - step);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        int st = getAnimState();
        rear = approach(rear, st == ST_REAR ? 1.0F : 0.0F, st == ST_REAR ? 0.12F : 0.2F);
        fire = approach(fire, st == ST_FIRE ? 1.0F : 0.0F, 0.2F);
        lash = approach(lash, st == ST_TAIL_WIND ? 1.0F : 0.0F, st == ST_TAIL_WIND ? 0.1F : 0.3F);
        snap = st == ST_TAIL_HIT ? 1.0F : Math.max(0.0F, snap - 0.1F);

        if (worldObj.isRemote) return;

        EntityLivingBase target = getAttackTarget();
        if (target == null) {
            fireWindup = tailWindup = strikeHold = volley = 0;
            setState(ST_IDLE);
            return;
        }

        if (!enraged && getHealth() < getMaxHealth() * 0.5F) enrage();

        if (strikeHold > 0) {
            setState(ST_TAIL_HIT);
            strikeHold--;
        } else if (tailWindup > 0) {
            // ง้างหาง: เตือนก่อนฟาดวงกว้างรอบตัว วิ่งออกนอกวงหรือปัดป้องได้
            getNavigator().clearPathEntity();
            setState(ST_TAIL_WIND);
            if (--tailWindup == 0) {
                tailSweep();
                strikeHold = 10;
                setState(ST_TAIL_HIT);
            }
        } else if (fireWindup > 0) {
            // ถอยหัวทุกหัวไปด้านหลังก่อนพ่นไฟ
            setState(ST_REAR);
            if (--fireWindup == 0) {
                volley = enraged ? 5 : 3;
                volleyDelay = 0;
            }
        } else if (volley > 0) {
            setState(ST_FIRE);
            if (--volleyDelay <= 0) {
                shoot(target);
                volley--;
                volleyDelay = 8;
            }
        } else {
            setState(ST_IDLE);
            double d2 = getDistanceSqToEntity(target);
            if (--tailCooldown <= 0 && d2 < 8.0D * 8.0D) {
                tailWindup = enraged ? 14 : 18;
                tailCooldown = enraged ? 70 : 110;
                worldObj.playSoundAtEntity(this, "mob.enderdragon.growl", 2.0F, 0.7F);
            } else if (--breathCooldown <= 0 && d2 < 28.0D * 28.0D) {
                fireWindup = 14;
                breathCooldown = enraged ? 80 : 130;
            }
        }
    }

    /** หางฟาดรอบตัว: ดาเมจและสะบัดผู้เล่นในรัศมีใกล้ตัว */
    private void tailSweep() {
        worldObj.playSoundAtEntity(this, "random.explode", 2.0F, 0.8F);
        ((WorldServer) worldObj).func_147487_a("explode", posX, posY + 0.3, posZ, 40, 3.0, 0.1, 3.0, 0.05);
        List list = worldObj.getEntitiesWithinAABB(EntityPlayer.class, boundingBox.expand(7.0D, 2.0D, 7.0D));
        for (Object o : list) {
            EntityPlayer p = (EntityPlayer) o;
            p.attackEntityFrom(DamageSource.causeMobDamage(this), enraged ? 10.0F : 7.0F);
            double dx = p.posX - posX, dz = p.posZ - posZ;
            double len = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
            p.addVelocity(dx / len * 1.6D, 0.6D, dz / len * 1.6D);
            p.velocityChanged = true;
        }
    }

    /** พ่นลูกไฟจากหัวสุ่มหัวหนึ่ง */
    private void shoot(EntityLivingBase target) {
        double hx = posX + (rand.nextDouble() - 0.5D) * 3.0D;
        double hy = posY + 3.0D + rand.nextDouble();
        double hz = posZ + (rand.nextDouble() - 0.5D) * 3.0D;
        double dx = target.posX - hx;
        double dy = target.boundingBox.minY + target.height / 2.0D - hy;
        double dz = target.posZ - hz;
        EntitySmallFireball fireball = new EntitySmallFireball(worldObj, this, dx, dy, dz);
        fireball.setPosition(hx, hy, hz);
        worldObj.spawnEntityInWorld(fireball);
        worldObj.playSoundAtEntity(this, "mob.ghast.fireball", 2.0F, 0.8F);
    }

    /** เลือดต่ำกว่าครึ่ง: เร็วขึ้น เรียกโอนิ 2 ตัว ยิงถี่ขึ้น */
    private void enrage() {
        enraged = true;
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.38D);
        for (int i = 0; i < 2; i++) {
            EntityOni oni = new EntityOni(worldObj);
            oni.setLocationAndAngles(posX + (i == 0 ? 4.0D : -4.0D), posY, posZ + 3.0D,
                    rand.nextFloat() * 360.0F, 0.0F);
            worldObj.spawnEntityInWorld(oni);
        }
        worldObj.playSoundAtEntity(this, "mob.wither.spawn", 2.0F, 0.7F);
        List players = worldObj.getEntitiesWithinAABB(EntityPlayer.class, boundingBox.expand(40.0D, 20.0D, 40.0D));
        for (Object o : players)
            ((EntityPlayer) o).addChatMessage(new ChatComponentText("ยามาตะโนะโอโรจิคลุ้มคลั่ง!"));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setBoolean("Enraged", enraged);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        enraged = tag.getBoolean("Enraged");
    }
}
