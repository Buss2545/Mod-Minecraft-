package com.example.samurai;

import java.lang.reflect.Field;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.ReflectionHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.util.ResourceLocation;

/** เปลี่ยนสกินผู้เล่นตามเพศ+คลาส (เห็นทั้งตัวเองและผู้เล่นคนอื่น รวมมือในมุมมองบุคคลที่ 1) */
@SideOnly(Side.CLIENT)
public class SkinHandler {
    private static final ResourceLocation[][] SKINS = new ResourceLocation[3][2];
    private static Field skinField;
    private static boolean failed;

    static {
        for (int c = 0; c < 3; c++)
            for (int g = 0; g < 2; g++)
                SKINS[c][g] = new ResourceLocation(SamuraiMod.MODID, "textures/skins/" + c + "_" + g + ".png");
        try {
            skinField = ReflectionHelper.findField(AbstractClientPlayer.class, "locationSkin", "field_110312_d");
        } catch (Exception ex) {
            failed = true; // หาฟิลด์ไม่เจอ: ปิดระบบสกิน เกมยังเล่นได้ปกติ
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || failed) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;

        for (Object o : mc.theWorld.playerEntities) {
            if (!(o instanceof AbstractClientPlayer)) continue;
            AbstractClientPlayer p = (AbstractClientPlayer) o;

            int v;
            try {
                v = p.getDataWatcher().getWatchableObjectInt(ProfileData.WATCHER_ID);
            } catch (Exception ex) {
                continue;
            }
            if (v < 0) continue;
            int cls = v & 255, gender = v >> 8;
            if (cls >= 3 || gender > 1) continue;

            try {
                skinField.set(p, SKINS[cls][gender]); // ตั้งซ้ำทุก tick เพราะสกินจริงโหลดมาทับได้ภายหลัง
            } catch (Exception ex) {
                failed = true;
            }
        }
    }
}
