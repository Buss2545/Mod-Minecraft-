package com.example.samurai;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

/**
 * ระบบต่อสู้ของคาตานะ
 *  - คอมโบ 3 ท่า: ฟันที่ 2 แรงขึ้นเล็กน้อย ฟันที่ 3 เป็นท่าจบ (แรง 1.6 เท่า + สะบัดศัตรู + ฟันกวาดวงกว้าง)
 *  - ฟันกวาด: ศัตรูรอบเป้าหมายด้านหน้าโดนดาเมจบางส่วนด้วย (ไม่โดนผู้เล่น/NPC)
 *  - ปัดป้อง (Parry): กดบล็อกด้วยคาตานะแล้วโดนตีในช่วง 8 tick แรก = ไม่โดนดาเมจ ศัตรูมึน และฟันต่อเป็นท่าจบทันที
 */
public class CombatEvents {
    private static final int COMBO_WINDOW = 30; // tick ที่ต้องฟันต่อให้ทัน
    private static final int PARRY_WINDOW = 8;  // tick แรกหลังเริ่มบล็อก

    private static final Map<UUID, long[]> COMBO = new HashMap<UUID, long[]>(); // {ท่าที่, tick ล่าสุด}
    private static boolean sweeping; // กันฟันกวาดวนซ้ำตัวเอง

    @SubscribeEvent
    public void onHurt(LivingHurtEvent e) {
        if (sweeping || e.entityLiving.worldObj.isRemote) return;
        if (!(e.source.getSourceOfDamage() instanceof EntityPlayer)) return;
        if (!"player".equals(e.source.getDamageType())) return;

        EntityPlayer p = (EntityPlayer) e.source.getSourceOfDamage();
        ItemStack held = p.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemKatana)) return;

        EntityLivingBase t = e.entityLiving;
        long now = p.worldObj.getTotalWorldTime();
        long[] c = COMBO.get(p.getUniqueID());
        int hit = (c == null || now - c[1] > COMBO_WINDOW) ? 1 : (int) c[0] + 1;
        if (hit > 3) hit = 1;
        COMBO.put(p.getUniqueID(), new long[] {hit, now});

        p.worldObj.playSoundAtEntity(p, "random.orb", 0.6F, 1.0F + hit * 0.2F);

        float radius = 1.6F, sweepMul = 0.4F;
        if (hit == 2) {
            e.ammount *= 1.15F;
        } else if (hit == 3) {
            e.ammount *= 1.6F;
            radius = 3.5F;
            sweepMul = 0.6F;
            knock(p, t, 1.1D, 0.35D);
            p.worldObj.playSoundAtEntity(p, "mob.irongolem.throw", 1.0F, 0.8F);
            if (p.worldObj instanceof WorldServer)
                ((WorldServer) p.worldObj).func_147487_a("crit", t.posX, t.posY + t.height / 2, t.posZ,
                        25, 0.5, 0.5, 0.5, 0.4);
        }

        slashArc(p, hit == 3);
        sweep(p, t, e.ammount * sweepMul, radius);
    }

    /** ปัดป้อง: บล็อกด้วยคาตานะตรงจังหวะ */
    @SubscribeEvent
    public void onAttack(LivingAttackEvent e) {
        if (!(e.entityLiving instanceof EntityPlayer) || e.entityLiving.worldObj.isRemote) return;
        EntityPlayer p = (EntityPlayer) e.entityLiving;
        if (!p.isBlocking() || e.source.isUnblockable()) return;

        ItemStack held = p.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemKatana)) return;

        Entity src = e.source.getSourceOfDamage();
        Entity attacker = e.source.getEntity();
        if (attacker == null && !e.source.isProjectile()) return; // ตก/ไฟ/ฯลฯ ปัดไม่ได้

        int heldTicks = held.getItem().getMaxItemUseDuration(held) - p.getItemInUseCount();
        if (heldTicks > PARRY_WINDOW) return; // เลยช่วงปัด: ใช้การบล็อกปกติของเกม

        e.setCanceled(true);
        if (e.source.isProjectile()) {
            if (src != null) src.setDead(); // ปัดลูกไฟ/ลูกธนูทิ้ง
        } else if (attacker instanceof EntityLivingBase) {
            EntityLivingBase a = (EntityLivingBase) attacker;
            knock(p, a, 1.3D, 0.3D);
            a.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 50, 3));
            a.addPotionEffect(new PotionEffect(Potion.weakness.id, 50, 1));
        }

        // โต้กลับ: ฟันครั้งต่อไปเป็นท่าจบทันที
        COMBO.put(p.getUniqueID(), new long[] {2, p.worldObj.getTotalWorldTime()});
        p.worldObj.playSoundAtEntity(p, "random.anvil_land", 0.8F, 1.8F);
        if (p.worldObj instanceof WorldServer) {
            WorldServer ws = (WorldServer) p.worldObj;
            ws.func_147487_a("crit", p.posX, p.posY + 1.2, p.posZ, 20, 0.5, 0.5, 0.5, 0.4);
            ws.func_147487_a("magicCrit", p.posX, p.posY + 1.2, p.posZ, 15, 0.4, 0.4, 0.4, 0.2);
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        COMBO.remove(e.player.getUniqueID());
    }

    private static void knock(EntityPlayer p, EntityLivingBase t, double horizontal, double vertical) {
        double dx = t.posX - p.posX, dz = t.posZ - p.posZ;
        double len = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
        t.addVelocity(dx / len * horizontal, vertical, dz / len * horizontal);
        t.velocityChanged = true;
    }

    /** ฟันกวาด: ศัตรูรอบเป้าหมายที่อยู่ด้านหน้าผู้เล่นโดนดาเมจด้วย */
    private static void sweep(EntityPlayer p, EntityLivingBase primary, float dmg, float r) {
        Vec3 look = p.getLookVec();
        double lx = look.xCoord, lz = look.zCoord;
        double ll = Math.sqrt(lx * lx + lz * lz);
        if (ll < 0.01D || dmg <= 0.0F) return;
        lx /= ll;
        lz /= ll;

        List list = p.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, primary.boundingBox.expand(r, 0.6D, r));
        sweeping = true;
        try {
            for (Object o : list) {
                if (o == primary || o == p || o instanceof EntityPlayer || o instanceof EntityNpc) continue;
                EntityLivingBase v = (EntityLivingBase) o;
                if (!v.isEntityAlive()) continue;
                double dx = v.posX - p.posX, dz = v.posZ - p.posZ;
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len > 0.01D && (dx * lx + dz * lz) / len < 0.2D) continue; // ต้องอยู่ด้านหน้า
                v.attackEntityFrom(DamageSource.causePlayerDamage(p), dmg);
            }
        } finally {
            sweeping = false;
        }
    }

    /** เส้นโค้งอนุภาคของคมดาบ */
    private static void slashArc(EntityPlayer p, boolean finisher) {
        if (!(p.worldObj instanceof WorldServer)) return;
        WorldServer ws = (WorldServer) p.worldObj;
        for (int k = -3; k <= 3; k++) {
            double ang = Math.toRadians(p.rotationYaw + 90.0D + k * (finisher ? 28.0D : 18.0D));
            double x = p.posX + Math.cos(ang) * 1.7D;
            double z = p.posZ + Math.sin(ang) * 1.7D;
            ws.func_147487_a(finisher ? "magicCrit" : "crit", x, p.posY + 1.1D + Math.abs(k) * -0.05D, z,
                    2, 0.0, 0.0, 0.0, 0.02);
        }
    }
}
