package com.example.samurai;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class EntityVillagerNpc extends EntityNpc {
    public static final int WORK = 0, PLAZA = 1, HOME = 2;
    public static final int NONE = 0, FARMER = 1, PRIEST = 2, GUARD = 3;
    private static final String[] NAMES = {"ชาวบ้าน", "ชาวนา", "ผู้ดูแลศาลเจ้า", "ทหารยามประตู"};

    private static final String[] LINES = {
        "ท่านปรมาจารย์เฒ่ารออยู่ ได้ข่าวว่าท่านจะตีดาบให้เด็กหนุ่มสักคน",
        "กลางคืนนี้น่ากลัวมาก พวกปีศาจเดินกันเต็มทุ่ง ช่วยพวกเราด้วย",
        "เขาว่ามีหลุมที่ลาวาไหลเป็นทางลงไปโยมิ ฉันไม่กล้าไปหรอก",
        "ผู้คนที่กลับจากโยมิเล่าว่า ได้ยินเสียงขู่ฟ่อจากงูยักษ์ทั้งแปดหัว",
        "คนแก่เล่าว่า สุดขอบฟ้ามีเกาะลอยฟ้า ไม่มีดวงอาทิตย์ ไม่มีกลางวัน",
        "ทุกคนในหมู่บ้านภาวนาให้ท่านชนะ ท้องฟ้ามืดมานานเกินไปแล้ว",
    };
    private static final String DONE = "ขอบคุณท่านซามูไร ลูกหลานของเราจะได้เห็นพระอาทิตย์อีกครั้ง";
    private static final String SLEEPY = "ฮ้าว... ดึกแล้ว พรุ่งนี้ค่อยคุยกันนะ ท่านซามูไร";

    public int profession = NONE;
    public boolean hasRoutine;
    public double homeX, homeY, homeZ, workX, workY, workZ, plazaX, plazaZ;

    public EntityVillagerNpc(World world) {
        super(world);
        tasks.addTask(0, new EntityAIRoutine(this, 0.8D)); // ลำดับสูงสุด: บังคับ AI เดินเล่นสุ่ม
    }

    public void setRoutine(int prof, double hx, double hy, double hz,
                           double wx, double wy, double wz, double px, double pz) {
        profession = prof;
        homeX = hx; homeY = hy; homeZ = hz;
        workX = wx; workY = wy; workZ = wz;
        plazaX = px; plazaZ = pz;
        hasRoutine = true;
    }

    private boolean isNightTime() {
        long t = worldObj.getWorldTime() % 24000L;
        return t >= 12000L && t < 23000L;
    }

    /** ช่วงเวลาของวัน: 06:00-15:00 ทำงาน / 15:00-18:00 พักที่ลาน / 18:00-05:00 อยู่บ้าน / ฝนตกหลบในบ้าน */
    public int getPhase() {
        long t = worldObj.getWorldTime() % 24000L;
        if (isNightTime() || worldObj.isRaining()) return HOME;
        if (t >= 9000L && t < 12000L) return PLAZA;
        return WORK;
    }

    public String getActivity() {
        int phase = getPhase();
        if (phase == HOME) return isNightTime() ? "งัวเงียอยู่ในบ้าน" : "หลบฝนอยู่ในบ้าน";
        if (phase == PLAZA) return "พักคุยกันที่ลานกลางหมู่บ้าน";
        switch (profession) {
            case FARMER: return "กำลังเก็บเกี่ยวข้าว";
            case PRIEST: return "กำลังกวาดลานหน้าศาลเจ้า";
            case GUARD:  return "ยืนเฝ้าประตูโทริอิ";
            default:     return "กำลังทำงาน";
        }
    }

    @Override
    protected String getSpeakerName() {
        return NAMES[Math.max(0, Math.min(profession, NAMES.length - 1))];
    }

    @Override
    protected String getLine(EntityPlayer p, StoryProperties s) {
        String act = hasRoutine ? "(" + getActivity() + ") " : "";
        if (hasRoutine && isNightTime()) return act + SLEEPY;
        return act + (s.isFinished() ? DONE : LINES[s.chapter]);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound t) {
        super.writeEntityToNBT(t);
        t.setInteger("Prof", profession);
        t.setBoolean("Routine", hasRoutine);
        t.setDouble("HomeX", homeX); t.setDouble("HomeY", homeY); t.setDouble("HomeZ", homeZ);
        t.setDouble("WorkX", workX); t.setDouble("WorkY", workY); t.setDouble("WorkZ", workZ);
        t.setDouble("PlazaX", plazaX); t.setDouble("PlazaZ", plazaZ);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound t) {
        super.readEntityFromNBT(t);
        profession = t.getInteger("Prof");
        hasRoutine = t.getBoolean("Routine");
        homeX = t.getDouble("HomeX"); homeY = t.getDouble("HomeY"); homeZ = t.getDouble("HomeZ");
        workX = t.getDouble("WorkX"); workY = t.getDouble("WorkY"); workZ = t.getDouble("WorkZ");
        plazaX = t.getDouble("PlazaX"); plazaZ = t.getDouble("PlazaZ");
    }
}
