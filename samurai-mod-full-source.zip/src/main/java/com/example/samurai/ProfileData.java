package com.example.samurai;

import java.util.UUID;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

/** เพศและคลาสของผู้เล่น เก็บใน NBT ถาวร (ไม่หายตอนตาย) */
public class ProfileData {
    public static final int MALE = 0, FEMALE = 1;
    public static final int SAMURAI = 0, NINJA = 1, PRIEST = 2;

    public static final String[] GENDERS = {"ชาย", "หญิง"};
    public static final String[] CLASS_NAMES = {"ซามูไร", "นินจา", "นักบวชศาลเจ้า"};
    public static final String[] CLASS_DESCS = {
        "เลือด +2 หัวใจ และดาบแรงขึ้น +1 เหมาะกับสายบู๊ตรงๆ",
        "วิ่งเร็วขึ้น 15% ตกจากที่สูงไม่เจ็บ และคูลดาวน์พุ่งสั้นลง 30%",
        "ฟื้นเลือดเองช้าๆ และโดนดาเมจน้อยลง 15% เหมาะกับสายทน"
    };

    private static final UUID HP_ID = UUID.fromString("5b0b2f1e-3c52-4d6a-9a1e-7f3c2a9d4e11");
    private static final UUID SPEED_ID = UUID.fromString("c1d8a7f2-6b34-4f0e-8e59-2d7a9b3c5f60");

    private static NBTTagCompound tag(EntityPlayer p) { return SkillData.sub(p, "SamuraiProfile"); }

    public static boolean isCreated(EntityPlayer p) { return tag(p).getBoolean("created"); }

    public static int getGender(EntityPlayer p) { return tag(p).getInteger("gender"); }

    /** คืน -1 ถ้ายังไม่ได้สร้างตัวละคร */
    public static int getClassId(EntityPlayer p) {
        NBTTagCompound t = tag(p);
        return t.getBoolean("created") ? t.getInteger("class") : -1;
    }

    public static void setProfile(EntityPlayer p, int gender, int cls) {
        NBTTagCompound t = tag(p);
        t.setInteger("gender", gender);
        t.setInteger("class", cls);
        t.setBoolean("created", cls >= 0);
    }

    /** ใส่/ถอดโบนัสค่าสถานะของคลาส เรียกซ้ำได้ปลอดภัย */
    public static void applyClass(EntityPlayer p) {
        int c = getClassId(p);
        mod(p, SharedMonsterAttributes.maxHealth, HP_ID, "samurai.hp", 4.0D, 0, c == SAMURAI);
        mod(p, SharedMonsterAttributes.movementSpeed, SPEED_ID, "samurai.speed", 0.15D, 2, c == NINJA);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
        syncWatcher(p);
    }

    /** ช่อง DataWatcher ที่ใช้ส่งเพศ/คลาสให้ผู้เล่นทุกคนเห็น (ใช้เลือกสกิน) */
    public static final int WATCHER_ID = 27;

    public static void initWatcher(EntityPlayer p) {
        try {
            p.getDataWatcher().addObject(WATCHER_ID, Integer.valueOf(-1));
        } catch (IllegalArgumentException ex) {
            // id ถูกใช้โดยม็อดอื่นแล้ว: ระบบสกินจะไม่ทำงาน
        }
    }

    /** ฝั่งเซิร์ฟเวอร์: อัปเดตค่าที่ส่งให้ไคลเอนต์ (-1 = ยังไม่สร้างตัวละคร) */
    public static void syncWatcher(EntityPlayer p) {
        if (p.worldObj.isRemote) return;
        int c = getClassId(p);
        try {
            p.getDataWatcher().updateObject(WATCHER_ID, Integer.valueOf(c < 0 ? -1 : (getGender(p) << 8) | c));
        } catch (RuntimeException ex) {
            // ไม่มีช่องนี้ ข้ามไป
        }
    }

    private static void mod(EntityPlayer p, IAttribute attr, UUID id, String name, double amount, int op, boolean on) {
        IAttributeInstance inst = p.getEntityAttribute(attr);
        AttributeModifier old = inst.getModifier(id);
        if (old != null) inst.removeModifier(old);
        if (on) inst.applyModifier(new AttributeModifier(id, name, amount, op).setSaved(false));
    }

    /** เรียกฝั่งเซิร์ฟเวอร์ตอนผู้เล่นกดยืนยันในหน้าสร้างตัวละคร */
    public static void create(EntityPlayerMP p, int gender, int cls) {
        if (isCreated(p)) return;
        if (gender < 0 || gender >= GENDERS.length || cls < 0 || cls >= CLASS_NAMES.length) return;

        setProfile(p, gender, cls);
        applyClass(p);
        p.setHealth(p.getMaxHealth());
        SkillData.sync(p);

        StoryProperties s = StoryProperties.get(p);
        if (s != null && !s.gotScroll) {
            s.gotScroll = true;
            p.inventory.addItemStackToInventory(new ItemStack(SamuraiMod.scroll));

            EntityElder elder = new EntityElder(p.worldObj);
            elder.setLocationAndAngles(p.posX + 2, p.posY, p.posZ, 0.0F, 0.0F);
            p.worldObj.spawnEntityInWorld(elder);

            JapaneseVillage.build(p.worldObj, (int) p.posX + 4, (int) p.posZ - 8);

            msg(p, EnumChatFormatting.GREEN, "ยินดีต้อนรับ " + (gender == MALE ? "ซามูไรหนุ่ม" : "ซามูไรสาว")
                    + " สายอาชีพ: " + CLASS_NAMES[cls]);
            s.showChapter(p);
            s.backup();
        }
    }

    private static void msg(EntityPlayer p, EnumChatFormatting color, String text) {
        ChatComponentText c = new ChatComponentText(text);
        c.getChatStyle().setColor(color);
        p.addChatMessage(c);
    }
}
