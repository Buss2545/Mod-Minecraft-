package com.example.samurai;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;

public class SkillData {
    public static final int COUNT = 5, MAX = 5;
    public static final int SHARP = 0, FLAME = 1, DASH = 2, WAVE = 3, GUARD = 4;

    public static final String[] NAMES = {"ดาบคม", "ดาบเพลิง", "พุ่งทะยาน", "คลื่นดาบ", "ผิวเหล็ก"};
    public static final String[] DESCS = {
        "ดาเมจดาบ +1 ต่อเลเวล",
        "ฟันแล้วศัตรูติดไฟ",
        "วิ่งแล้วคลิกขวา พุ่งฟัน",
        "Shift + คลิกขวา ยิงคลื่นดาบ",
        "ลดดาเมจที่โดน 6% ต่อเลเวล"
    };

    /** ดึง NBT ย่อยที่คงอยู่ถาวรของผู้เล่น (รอดตอนตาย) */
    public static NBTTagCompound sub(EntityPlayer p, String name) {
        NBTTagCompound data = p.getEntityData();
        if (!data.hasKey(EntityPlayer.PERSISTED_NBT_TAG))
            data.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        NBTTagCompound persisted = data.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        if (!persisted.hasKey(name))
            persisted.setTag(name, new NBTTagCompound());
        return persisted.getCompoundTag(name);
    }

    private static NBTTagCompound tag(EntityPlayer p) { return sub(p, "SamuraiSkills"); }

    public static int getLevel(EntityPlayer p, int id) { return tag(p).getInteger("s" + id); }
    public static void setLevel(EntityPlayer p, int id, int lv) { tag(p).setInteger("s" + id, lv); }

    public static long getDashReady(EntityPlayer p) { return tag(p).getLong("dashReady"); }
    public static void setDashReady(EntityPlayer p, long t) { tag(p).setLong("dashReady", t); }

    public static long getWaveReady(EntityPlayer p) { return tag(p).getLong("waveReady"); }
    public static void setWaveReady(EntityPlayer p, long t) { tag(p).setLong("waveReady", t); }

    /** ราคาอัพเป็นเลเวล XP: 3, 5, 7, 9, 11 */
    public static int cost(int level) { return 3 + level * 2; }

    public static void tryUpgrade(EntityPlayerMP p, int id) {
        if (id < 0 || id >= COUNT) return;
        int lv = getLevel(p, id);
        if (lv >= MAX) return;
        int c = cost(lv);
        boolean free = p.capabilities.isCreativeMode;
        if (!free && p.experienceLevel < c) return;
        if (!free) p.addExperienceLevel(-c);
        setLevel(p, id, lv + 1);
        p.worldObj.playSoundAtEntity(p, "random.levelup", 0.8F, 1.0F);
    }

    public static void sync(EntityPlayer p) {
        if (p instanceof EntityPlayerMP)
            NetworkHandler.NET.sendTo(new PacketSync(p), (EntityPlayerMP) p);
    }
}
