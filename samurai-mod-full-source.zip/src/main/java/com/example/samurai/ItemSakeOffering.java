package com.example.samurai;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** เครื่องบูชาสาเก: คลิกขวาที่พื้นในโยมิ (Nether) เพื่อเรียกยามาตะโนะโอโรจิ */
public class ItemSakeOffering extends Item {
    public ItemSakeOffering() {
        setUnlocalizedName("sakeOffering");
        setTextureName(SamuraiMod.MODID + ":sake_offering");
        setCreativeTab(CreativeTabs.tabMisc);
        setMaxStackSize(1);
    }

    @Override
    public boolean hasEffect(ItemStack stack, int pass) { return true; }

    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world,
                             int x, int y, int z, int side, float hx, float hy, float hz) {
        if (world.isRemote) return true;
        if (world.provider.dimensionId != -1) {
            player.addChatMessage(new ChatComponentText("เครื่องบูชานี้ใช้ได้เฉพาะในโยมิ (Nether) เท่านั้น"));
            return false;
        }
        EntityOrochi boss = new EntityOrochi(world);
        boss.setLocationAndAngles(x + 0.5D, y + 1.0D, z + 0.5D, player.rotationYaw + 180.0F, 0.0F);
        StoryProperties st = StoryProperties.get(player);
        if (st != null) NgPlus.scale(boss, st.ng); // NG+: บอสแกร่งขึ้น
        world.spawnEntityInWorld(boss);
        world.playSoundAtEntity(player, "mob.wither.spawn", 1.0F, 0.8F);
        if (!player.capabilities.isCreativeMode) stack.stackSize--;
        return true;
    }
}
