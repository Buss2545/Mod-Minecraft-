package com.example.samurai;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

public class StoryEvents {

    // ผูกข้อมูลเรื่องเข้ากับผู้เล่น
    @SubscribeEvent
    public void onConstruct(EntityEvent.EntityConstructing e) {
        if (e.entity instanceof EntityPlayer) {
            EntityPlayer p = (EntityPlayer) e.entity;
            ProfileData.initWatcher(p);
            if (StoryProperties.get(p) == null) StoryProperties.register(p);
        }
    }

    // เข้าโลก: กู้ข้อมูลเรื่อง (การแจกม้วนคัมภีร์/เสกปรมาจารย์/สร้างหมู่บ้าน ย้ายไปอยู่ใน ProfileData.create
    // ซึ่งทำงานหลังผู้เล่นเลือกเพศและคลาสเสร็จ)
    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent e) {
        if (e.world.isRemote || !(e.entity instanceof EntityPlayer)) return;
        StoryProperties s = StoryProperties.get((EntityPlayer) e.entity);
        if (s != null) s.restoreFromBackup();
    }

    // ตอนที่ 1: คราฟต์คาตานะ
    @SubscribeEvent
    public void onCraft(PlayerEvent.ItemCraftedEvent e) {
        if (e.player.worldObj.isRemote || e.crafting == null) return;
        StoryProperties s = StoryProperties.get(e.player);
        if (s != null && s.chapter == 0 && e.crafting.getItem() == SamuraiMod.katana) {
            s.advance();
        }
    }

    // ตอนที่ 3 และ 5: เปลี่ยนมิติ
    @SubscribeEvent
    public void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        StoryProperties s = StoryProperties.get(e.player);
        if (s == null) return;
        if (s.chapter == 2 && e.toDim == -1) s.advance();
        else if (s.chapter == 4 && e.toDim == 1) s.advance();

        // NG+: มังกรไม่เกิดใหม่เองใน 1.7.10 จึงเสกให้ใหม่เมื่อเข้า The End ตอนที่ 6
        if (e.toDim == 1 && s.ng > 0 && s.chapter == 5) NgPlus.ensureDragon(e.player, s.ng);
    }

    // ตอนที่ 2, 4, 6: ฆ่าศัตรู
    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (e.entityLiving.worldObj.isRemote) return;

        if (e.entityLiving instanceof EntityPlayer) {
            StoryProperties dead = StoryProperties.get((EntityPlayer) e.entityLiving);
            if (dead != null) dead.backup();
            return;
        }

        if (!(e.source.getEntity() instanceof EntityPlayer)) return;
        EntityPlayer killer = (EntityPlayer) e.source.getEntity();
        StoryProperties s = StoryProperties.get(killer);
        if (s == null) return;

        if (s.chapter == 1 && e.entityLiving instanceof EntityOniKing) {
            if (s.zombieKills >= StoryManager.ZOMBIES_NEEDED) s.advance();
        } else if (s.chapter == 1 && e.entityLiving instanceof EntityOni) {
            if (s.zombieKills >= StoryManager.ZOMBIES_NEEDED) return; // ช่วงรอสู้โอนิราชา ไม่นับต่อ
            s.zombieKills++;
            if (s.zombieKills >= StoryManager.ZOMBIES_NEEDED) {
                s.backup();
                EntityOniKing.summonNear(killer);
                s.showChapter(killer);
            } else {
                s.backup();
                s.showChapter(killer);
            }
        } else if (s.chapter == 3 && e.entityLiving instanceof EntityOrochi) {
            s.advanceSilently(); // บันทึกความคืบหน้าทันที กันข้อมูลหายถ้าหลุดกลางคัตซีน
            CutsceneManager.start(killer, 0, e.entityLiving.posX, e.entityLiving.posY, e.entityLiving.posZ);
        } else if (s.chapter == 5 && e.entityLiving instanceof EntityDragon) {
            s.advanceSilently(); // ฉากจบเกมแจกรางวัลและแสดงข้อความจบเอง
            CutsceneManager.start(killer, 1, e.entityLiving.posX, e.entityLiving.posY, e.entityLiving.posZ);
        }
    }
}
