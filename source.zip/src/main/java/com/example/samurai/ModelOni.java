package com.example.samurai;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/** โมเดลโอนิ: ท่าแขนตามสถานะ เห็นเป้าหมาย (แขนยื่นไปข้างหน้า) / ง้างเตรียมทุบ (ยกเหนือหัว) / ฟาดลง */
@SideOnly(Side.CLIENT)
public class ModelOni extends ModelBiped {
    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age,
                                  float yaw, float pitch, float scale, Entity entity) {
        super.setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        if (!(entity instanceof EntityOni)) return;

        EntityOni o = (EntityOni) entity;
        if (o.aggro <= 0.0F && o.raise <= 0.0F && o.swing <= 0.0F) return; // ท่าเดินปกติของ ModelBiped

        float a = -1.45F * o.aggro + MathHelper.sin(age * 0.25F) * 0.05F * o.aggro;
        a += (-3.0F - a) * o.raise;  // ยกแขนขึ้นเหนือหัว
        a += (-0.1F - a) * o.swing;  // ฟาดลง
        bipedRightArm.rotateAngleX = a;
        bipedLeftArm.rotateAngleX = a;
        bipedRightArm.rotateAngleZ = 0.08F;
        bipedLeftArm.rotateAngleZ = -0.08F;
    }
}
