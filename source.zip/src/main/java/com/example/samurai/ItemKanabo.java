package com.example.samurai;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

/** คะนะโบะ: กระบองเหล็กของโอนิราชา ตีแล้วศัตรูกระเด็น */
public class ItemKanabo extends ItemSword {
    public ItemKanabo(ToolMaterial material) {
        super(material);
        setUnlocalizedName("kanabo");
        setTextureName(SamuraiMod.MODID + ":kanabo");
        setCreativeTab(CreativeTabs.tabCombat);
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        double dx = target.posX - attacker.posX, dz = target.posZ - attacker.posZ;
        double len = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
        target.addVelocity(dx / len * 0.9D, 0.3D, dz / len * 0.9D);
        target.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 30, 1)); // ทุบแล้วมึน
        return super.hitEntity(stack, target, attacker);
    }
}
