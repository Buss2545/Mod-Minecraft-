package com.example.samurai;

import java.util.List;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import org.lwjgl.opengl.GL11;

/** ขอบดำแบบหนัง + คำบรรยาย + การ์ดชื่อตอน (id 1 มีเครดิตเลื่อนด้วย) */
@SideOnly(Side.CLIENT)
public class CutsceneOverlay {
    private static final int[] DURATION = {330, 960};

    // {เริ่ม, จบ} (tick) คู่กับข้อความของแต่ละฉาก
    private static final int[][][] TIMES = {
        {{30, 110}, {120, 195}, {200, 270}},
        {{30, 130}, {140, 240}, {250, 350}}
    };
    private static final String[][] LINES = {
        {
            "ยามาตะโนะโอโรจิ: ...ข้าเป็นเพียงผู้เฝ้าตราผนึก... ต้นตอของคำสาปอยู่เหนือขอบฟ้า...",
            "เสียงจากเหล่าเทพ: ดาบคุซานางิตื่นแล้ว เจ้าคู่ควรกับมัน ผู้กล้า",
            "หยกมะงะตะมะส่องประกาย คำสาปแห่งโยมิคลายลง"
        },
        {
            "มังกรแห่งรัตติกาลล้มลง... แสงแรกเล็ดลอดผ่านขอบฟ้า",
            "เหล่าเทพ: เจ้าทำลายคำสาปได้แล้ว อาทิตย์จะอุทัยขึ้นอีกครั้ง",
            "ซามูไรผู้นั้นกลับสู่หมู่บ้านซากุระ พร้อมตำนานที่จะถูกเล่าขานไปอีกพันปี"
        }
    };
    private static final String[] TITLE = {"จบตอนที่ 4", "จบบริบูรณ์"};
    private static final String[] SUB = {"ยามาตะโนะโอโรจิ", "ตำนานดาบแห่งอาทิตย์อุทัย"};
    private static final int[] TITLE_AT = {275, 850};

    // เครดิต (ฉาก id 1): บรรทัดขึ้นต้นด้วย # = หัวข้อสีทอง
    private static final int CREDITS_START = 360, CREDITS_LEN = 470;
    private static final String[] CREDITS = {
        "#ตำนานดาบแห่งอาทิตย์อุทัย", "",
        "#ซามูไรแห่งตำนาน", "{player}", "",
        "#ผู้ให้คำแนะนำ", "ปรมาจารย์เฒ่า", "",
        "#ชาวบ้านแห่งหมู่บ้านซากุระ", "ชาวนา", "ผู้ดูแลศาลเจ้า", "ทหารยามประตู", "",
        "#ศัตรูที่ผ่านมา", "โอนิ", "โอนิราชา", "ยามาตะโนะโอโรจิ", "มังกรแห่งรัตติกาล", "",
        "#ของวิเศษ", "ดาบคาตานะ", "ดาบคุซานางิ", "หยกมะงะตะมะ", "คะนะโบะ", "",
        "#สร้างด้วย", "Minecraft 1.7.10", "Minecraft Forge", "",
        "ขอบคุณที่ร่วมเดินทางด้วยกัน"
    };

    private static volatile boolean active;
    private static volatile int ticks;
    private static volatile int scene;

    public static void start(int id) {
        if (id < 0 || id >= DURATION.length) return;
        scene = id;
        ticks = 0;
        active = true;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !active) return;
        if (++ticks > DURATION[scene]) active = false;
    }

    @SubscribeEvent
    @SuppressWarnings("rawtypes")
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (!active || e.type != RenderGameOverlayEvent.ElementType.ALL) return;

        int id = scene;
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRenderer;
        int w = e.resolution.getScaledWidth(), h = e.resolution.getScaledHeight();
        float t = ticks + e.partialTicks;
        int dur = DURATION[id];

        // ขอบดำเลื่อนเข้า/ออก 1 วินาที
        float k = Math.max(0.0F, Math.min(1.0F, Math.min(t / 20.0F, (dur - t) / 20.0F)));
        int bar = (int) (h * 0.15F * k);
        Gui.drawRect(0, 0, w, bar, 0xFF000000);
        Gui.drawRect(0, h - bar, w, h, 0xFF000000);

        // เครดิตเลื่อนขึ้น (เฉพาะฉากจบเกม)
        if (id == 1 && t >= CREDITS_START) {
            float dim = Math.min(1.0F, (t - CREDITS_START) / 30.0F);
            Gui.drawRect(0, bar, w, h - bar, ((int) (170 * dim)) << 24);
            String name = mc.getSession().getUsername();
            float travel = Math.min(1.0F, (t - CREDITS_START) / (float) CREDITS_LEN) * (h + CREDITS.length * 14);
            for (int i = 0; i < CREDITS.length; i++) {
                float y = h - travel + i * 14;
                if (y < bar + 2 || y > h - bar - 10) continue;
                String raw = CREDITS[i].replace("{player}", name);
                boolean head = raw.startsWith("#");
                String text = head ? raw.substring(1) : raw;
                if (text.length() == 0) continue;
                fr.drawStringWithShadow(text, (w - fr.getStringWidth(text)) / 2, (int) y, head ? 0xFFD700 : 0xFFFFFF);
            }
        }

        // คำบรรยายในขอบล่าง
        for (int i = 0; i < LINES[id].length; i++) {
            if (t >= TIMES[id][i][0] && t < TIMES[id][i][1]) {
                List lines = fr.listFormattedStringToWidth(LINES[id][i], w - 40);
                int y = h - bar + (bar - lines.size() * 10) / 2;
                for (Object o : lines) {
                    String line = (String) o;
                    fr.drawStringWithShadow(line, (w - fr.getStringWidth(line)) / 2, y, 0xFFFFFF);
                    y += 10;
                }
            }
        }

        // การ์ดชื่อตอนท้ายฉาก
        if (t >= TITLE_AT[id]) {
            GL11.glPushMatrix();
            GL11.glScalef(2.0F, 2.0F, 1.0F);
            fr.drawStringWithShadow(TITLE[id],
                    (int) (w / 4.0F - fr.getStringWidth(TITLE[id]) / 2.0F), (int) ((h / 2.0F - 24.0F) / 2.0F), 0xFFD700);
            GL11.glPopMatrix();
            fr.drawStringWithShadow(SUB[id], (w - fr.getStringWidth(SUB[id])) / 2, h / 2 + 2, 0xFFFFFF);
        }
    }
}
