package com.example.samurai;

import net.minecraft.entity.player.EntityPlayer;

public class CommonProxy {
    public void registerRenderers() {}
    public EntityPlayer getPlayer() { return null; }
    public void requestCreateGui() {}
    public void startCutscene(int id) {}
}
