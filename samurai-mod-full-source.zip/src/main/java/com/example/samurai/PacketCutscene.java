package com.example.samurai;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;

/** เซิร์ฟเวอร์สั่งให้ไคลเอนต์เริ่มคัตซีน (ขอบดำ + คำบรรยาย) */
public class PacketCutscene implements IMessage {
    public int id;

    public PacketCutscene() {}
    public PacketCutscene(int id) { this.id = id; }

    @Override public void fromBytes(ByteBuf buf) { id = buf.readInt(); }
    @Override public void toBytes(ByteBuf buf) { buf.writeInt(id); }

    public static class Handler implements IMessageHandler<PacketCutscene, IMessage> {
        @Override
        public IMessage onMessage(PacketCutscene msg, MessageContext ctx) {
            SamuraiMod.proxy.startCutscene(msg.id);
            return null;
        }
    }
}
