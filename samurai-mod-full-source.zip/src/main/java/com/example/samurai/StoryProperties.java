package com.example.samurai;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.World;
import net.minecraftforge.common.IExtendedEntityProperties;

public class StoryProperties implements IExtendedEntityProperties {
    public static final String ID = "SamuraiStory";

    // สำรองข้อมูล เพราะตอนตายหรือกลับจาก The End ผู้เล่นจะถูกสร้างใหม่
    private static final Map<UUID, NBTTagCompound> BACKUP = new HashMap<UUID, NBTTagCompound>();

    public int chapter = 0;
    public int zombieKills = 0;
    public boolean gotScroll = false;
    public int ng = 0;                 // จำนวนรอบ NG+ ที่เล่นแล้ว
    public long ngConfirmUntil = 0L;   // ไม่บันทึก ใช้ยืนยันการเริ่ม NG+

    private EntityPlayer player;

    public static void register(EntityPlayer p) {
        p.registerExtendedProperties(ID, new StoryProperties());
    }

    public static StoryProperties get(EntityPlayer p) {
        return (StoryProperties) p.getExtendedProperties(ID);
    }

    public boolean isFinished() {
        return chapter >= StoryManager.total();
    }

    public void advance() {
        EntityPlayer p = player;
        reward(p, chapter);
        chapter++;
        zombieKills = 0;
        if (isFinished()) {
            msg(p, EnumChatFormatting.GREEN, StoryManager.ENDING);
        } else {
            showChapter(p);
        }
        backup();
    }

    /** เลื่อนตอนทันทีโดยไม่แจกรางวัล/ไม่แสดงข้อความ (คัตซีนจะเรียก reward + showChapter เองตอนจบ) */
    public void advanceSilently() {
        chapter++;
        zombieKills = 0;
        backup();
    }

    /** เริ่มเนื้อเรื่องรอบใหม่ เก็บสกิล/คลาส/ของในตัวไว้ครบ (ถ้ามีดาบอยู่แล้วข้ามตอนที่ 1) */
    public void startNewGamePlus(EntityPlayer p) {
        ng++;
        zombieKills = 0;
        boolean armed = p.inventory.hasItem(SamuraiMod.katana) || p.inventory.hasItem(SamuraiMod.kusanagi);
        chapter = armed ? 1 : 0;
        msg(p, EnumChatFormatting.LIGHT_PURPLE, "เริ่มการเดินทางรอบใหม่ NG+" + ng
                + " บอสแข็งแกร่งขึ้น รางวัล XP มากขึ้น สกิลยังอยู่ครบ");
        if (armed) msg(p, EnumChatFormatting.GRAY, "เจ้ามีดาบอยู่แล้ว ข้ามตอนที่ 1");
        showChapter(p);
        backup();
    }

    public void showChapter(EntityPlayer p) {
        if (isFinished()) {
            msg(p, EnumChatFormatting.GREEN, StoryManager.ENDING);
            return;
        }
        msg(p, EnumChatFormatting.GOLD, "== " + StoryManager.TITLES[chapter] + (ng > 0 ? " [NG+" + ng + "]" : "") + " ==");
        msg(p, EnumChatFormatting.WHITE, StoryManager.TEXTS[chapter]);
        String goal = StoryManager.GOALS[chapter];
        if (chapter == 1) {
            if (zombieKills >= StoryManager.ZOMBIES_NEEDED)
                goal = "เป้าหมาย: ฆ่าโอนิราชา (หาไม่เจอ คลิกขวาม้วนคัมภีร์เพื่อเรียกใหม่)";
            else
                goal += " (" + zombieKills + "/" + StoryManager.ZOMBIES_NEEDED + ")";
        }
        msg(p, EnumChatFormatting.YELLOW, goal);
    }

    public void reward(EntityPlayer p, int doneChapter) {
        switch (doneChapter) {
            case 0: give(p, new ItemStack(Items.bread, 8)); break;
            case 1: give(p, new ItemStack(Items.iron_helmet)); give(p, new ItemStack(Items.iron_chestplate)); break;
            case 2: give(p, new ItemStack(Items.golden_apple, 2)); break;
            case 3:
                give(p, new ItemStack(Items.diamond, 5));
                give(p, new ItemStack(SamuraiMod.magatama));
                p.addExperienceLevel(5); // โบนัสบอส
                msg(p, EnumChatFormatting.LIGHT_PURPLE, "ได้รับ หยกมะงะตะมะ และโบนัส 5 เลเวล XP!");
                break;
            case 4: give(p, new ItemStack(Items.ender_pearl, 8)); break;
            case 5: give(p, new ItemStack(Items.nether_star)); break;
        }
        int xp = 5 + ng * 2; // NG+ ได้ XP เพิ่มรอบละ 2 เลเวล
        p.addExperienceLevel(xp);
        msg(p, EnumChatFormatting.GREEN, "ได้รับ " + xp + " เลเวล XP กด K เพื่ออัพสกิล");
        msg(p, EnumChatFormatting.AQUA, "ได้รับรางวัลจบตอน!");
    }

    private void give(EntityPlayer p, ItemStack s) {
        if (!p.inventory.addItemStackToInventory(s)) p.dropPlayerItemWithRandomChoice(s, false);
    }

    private static void msg(EntityPlayer p, EnumChatFormatting color, String text) {
        ChatComponentText c = new ChatComponentText(text);
        c.getChatStyle().setColor(color);
        p.addChatMessage(c);
    }

    public void backup() {
        if (player == null) return;
        NBTTagCompound tag = new NBTTagCompound();
        saveNBTData(tag);
        BACKUP.put(player.getUniqueID(), tag);
    }

    public void restoreFromBackup() {
        NBTTagCompound tag = BACKUP.get(player.getUniqueID());
        if (tag != null) loadNBTData(tag);
    }

    @Override
    public void saveNBTData(NBTTagCompound compound) {
        NBTTagCompound t = new NBTTagCompound();
        t.setInteger("chapter", chapter);
        t.setInteger("zombies", zombieKills);
        t.setBoolean("scroll", gotScroll);
        t.setInteger("ng", ng);
        compound.setTag(ID, t);
    }

    @Override
    public void loadNBTData(NBTTagCompound compound) {
        if (compound.hasKey(ID)) {
            NBTTagCompound t = compound.getCompoundTag(ID);
            chapter = t.getInteger("chapter");
            zombieKills = t.getInteger("zombies");
            gotScroll = t.getBoolean("scroll");
            ng = t.getInteger("ng");
        }
    }

    @Override
    public void init(Entity entity, World world) {
        if (entity instanceof EntityPlayer) player = (EntityPlayer) entity;
    }
}
